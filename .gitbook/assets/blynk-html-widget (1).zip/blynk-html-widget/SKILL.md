---
name: "blynk-html-widget"
description: Generate a self-contained HTML widget for the Blynk dashboard, wired to the BlynkBridge JavaScript API, that works on both the web dashboard and the Blynk Android/iOS apps. Use this whenever the user wants a Blynk widget, an HTML Widget, a custom dashboard tile, or describes an IoT dashboard display/control need — a gauge, slider, switch, level/progress bar, value-or-label card, chart, map/location track, device metadata card, or page-navigation menu — whether they name the UI element ("I need a slider that sets the target temp") or only state the need ("show me the humidity over the last day", "show where the truck has been", "show the installation room"). Also trigger when editing, restyling or debugging existing Blynk widget HTML, or wiring widget JavaScript to datastream values, the app theme, historical or map data, device info or metadata, date ranges, or mobile pages. Do not wait for the literal word "widget"; an IoT control/display need on Blynk is enough.
---

# Blynk HTML Widget Generator

Produce one self-contained `.html` file the user can upload as a Blynk HTML Widget with no further edits. The host — the **web dashboard** or the **Android/iOS app** — injects a `BlynkBridge` class; through it the widget reads and writes datastreams, gets live pushes, the app theme, history and map data, device info and metadata, and (on mobile) opens pages. The same file runs everywhere, so it branches on capability checks, never on host name.

Write code that is clean, well-structured and above all easy for a human to read: consistently indented and nicely formatted HTML, CSS and JS, with clear names. Keep code comments short — one line on *why*, not paragraphs on *what*.

The hard part is **interpretation**: the request sometimes names a UI element and sometimes only states a need. Pick the component that best serves the need; compose or invent a layout when nothing in the table fits.

## Workflow

1. **Choose a component** (table below) — does it read, write, or both?
2. **Map datastreams** — one source per requested datastream, discovered at runtime.
3. **Plan web vs mobile** — which capabilities it touches (rules below, details in `references/platforms.md`).
4. **Copy `assets/skeleton.html`** and build on it; for history/map widgets add the helper code from `platforms.md` §6.
5. **Style it** — user style or screenshot first, else the component's reference image for layout and color, else the Blynk baseline (rounded cards with filled blocks, `style.md` §9); always within `references/style.md`.
6. **Validate** — `python3 scripts/validate_widget.py widget.html`; fix every FAIL and every WARN that isn't deliberate.
7. **Visual check** — one call: `python3 scripts/render_check.py widget.html`. It renders light, dark and web into a single image; view that image once and re-render only after fixing something you saw. Skip it for edits that can't change layout, tokens or theme handling (copy, a label, a number format) and rely on the validator. Details: `style.md` §11.
8. **Present** the `.html` with `present_files`.

## Read only what the widget touches

The reference files are long and every line read costs context. Read a file whole only when it is short or all of it applies; otherwise read the section you need with `python3 scripts/read_section.py <file> <number or heading text>` (run it with just the file to list sections).

- `references/bridge-api.md` (short) — read it when you write bridge calls.
- `references/components.md` — the one family you chose.
- `references/style.md` — §2–4 and §9 for every widget; the rest as needed.
- `references/platforms.md` — history or map: §2 and §6. Page navigation: §3. Text input: §5. Unsure what differs: §1. Not the whole file.
- `references/metadata.md` — **only** for a widget that shows or edits device metadata (device name, location, owner, contact, serials). Datastream-only widgets skip it; `bridge-api.md` §7 already has the three calls. When you do need it, read it before writing the code: the value shapes and the list of types that accept a patch aren't guessable.

If the references already cover the bridge call you need, don't search the web for it; use the developer guide (linked at the end) only for details they don't cover.

## Choose a component

| Need / phrasing | Component | R/W | Reference image |
|---|---|---|---|
| "set / adjust / control" a numeric value | Slider (vertical, horizontal, dial) | Write | `slider.webp` |
| "turn on/off", pick a mode, fire an action, step ± | Switch / selector / button / stepper | Write | `Buttons_swicthes.webp` |
| "history", "trend", "over time", "last N hours/days" | Chart (line, bar, sparkline…) | Read | `CHARTS.webp` |
| "progress", "fill", "level", "% of capacity" | Horizontal level / threshold bar | Read | `horizontal_level.webp` |
| a single current value with a known min/max | Gauge, ring | Read | `gauges.webp` |
| current value(s) with no time axis, several metrics | Value / label card | Read | `LABEL_CARD_VALUE.webp` |
| "where is it", "route", "track", GPS | Map / location track (SVG, no tiles) | Read | — |
| device properties: location, serial, owner, contact; "let me edit the room / time zone" | Device metadata card | Read, edit the patchable types | — |
| "open / go to the … page", back, home | Page navigation (mobile only) | Action | — |

The reference images live in `assets/refs/`; view the matching one before writing CSS. Take layout, hierarchy and color from it, but corners from `style.md` §9: the sheets predate the rounded-card baseline and may show square corners.

## Datastreams

- Count and types come from `getValues()` at runtime (0-based `index`, configured order). Never hardcode a count: show "Assign a datastream" when empty, a placeholder layout in the editor preview (no bridge), a loading state meanwhile.
- Read components may aggregate several streams in one tile; write components render one control per stream.
- A datastream the user names explicitly → selector `getValue({ name: 'Temperature' })`.
- **Parse values with `toNumber()`, never `parseFloat`** — they can arrive locale-formatted (`"4,758"`), and `parseFloat` returns 4.

## Web vs mobile — the two key rules

- **History and map widgets:** on web the dashboard's range picker drives the window (`RANGE_PICKER`) — never duplicate it inside the widget. Where `isRangePickerSupported()` is false (mobile, editor), the widget shows its **own** period picker (`createPeriodPicker`: `6h · 24h · 7d · 30d` + custom) and fetches with `CUSTOM`. Wiring: `platforms.md` §2.
- **Page navigation exists only on mobile.** Guard with `isPageActionsSupported()`. On web, hide navigation that is an add-on; if navigation is the whole widget, show it disabled with "Pages open in the Blynk mobile app". Details: `platforms.md` §3.

## Build on the skeleton

`assets/skeleton.html` already passes the validator. Keep its theme tokens, iframe reset, bridge stub (so the editor preview renders), single `setCallbacks` call before any read, and boot order (`applyTheme(await getTheme())` → `getValues()` → render; merge pushes by `index`, render idempotently).

The skeleton already contains the number and theme helpers (`toNumber`, `formatNumber`, `formatValue`, `streamName`, `withAlpha`, `isDark`, `applyTheme`). History and map widgets add the date, bucket, tick, scrubbing and period-picker code from `platforms.md` §6. Reuse these rather than rewriting them.

Every Promise request already shows its own error toast, so a `.catch()` only updates the widget's state ("--", "Could not load data") — don't call `sendError` again.

## Must hold, whatever the look

- **Light/dark follows the app theme**, never the OS: `applyTheme` sets `data-theme`; every mode-dependent color is a `[data-theme]` token.
- **Text colors from the text ramp** (`--text-primary`, `--text-secondary`, `--text-muted`). Never `theme.textPrimary` or brand colors for text.
- **Fixed date/number formats** (`18 Sep 2026`, `14:00`), no `toLocale*` / `Intl`.
- **Transparent tile background**, **no outer padding**, **no glow** unless the user asks. Cards inside the tile are white in the light theme (`--card`) with a subtle border, and the blocks inside them are filled (`--block`); radius and surface rules are in `style.md` §9.
- **≤ 100,000 characters**, **no external resources** (no CDN scripts, fonts, images or map tiles — inline SVG only), **no `innerHTML` with bridge data**.
- **Every Promise gets `.catch()`**; newer optional methods are checked with `typeof bridge.x === 'function'`.
- Don't add `overscroll-behavior: none`; long content scrolls inside an inner `overflow-y: auto` region.

When a bridge detail isn't covered here, the public developer guide is the source of truth: https://docs.blynk.io/en/blynk.console/widgets-console/html-widget/html-widget-developer-guide
