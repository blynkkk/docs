#!/usr/bin/env python3
"""Render a Blynk widget in several host variants and stitch ONE contact-sheet image.

Usage:
  python3 render_check.py widget.html
  python3 render_check.py widget.html --level max --size 380x300
  python3 render_check.py widget.html --variants light-mobile,dark-mobile,light-web,dark-web
  python3 render_check.py widget.html --values my_streams.json --click ".row:nth-child(2)"

Variants (name = app theme + host):
  light-mobile  light app theme, OS dark,  page actions on,  no range picker
  dark-mobile   dark app theme,  OS light, page actions on,  no range picker
  light-web     light app theme, OS dark,  range picker on,  no page actions
  dark-web      dark app theme,  OS light, range picker on,  no page actions
Default: light-mobile, dark-mobile, light-web. The OS is set opposite to the app
theme on purpose, so a color chosen by prefers-color-scheme shows up as a bug.

The mock bridge serves the values and capabilities chosen here. It catches layout,
contrast and theme bugs; it cannot tell you what a real host returns.

Prints the output path, console/page errors per variant, and the bridge calls the
widget made (sendValue, showPage, ...) after an optional --click.
"""
import argparse
import json
import sys
import tempfile
import time
from pathlib import Path

VARIANTS = {
    "light-mobile": dict(bg="#F7F7F8", theme="#F7F7F8FF", os="dark",  pages=True,  picker=False),
    "dark-mobile":  dict(bg="#1C1C1F", theme="#1C1C1FFF", os="light", pages=True,  picker=False),
    "light-web":    dict(bg="#F7F7F8", theme="#F7F7F8FF", os="dark",  pages=False, picker=True),
    "dark-web":     dict(bg="#1C1C1F", theme="#1C1C1FFF", os="light", pages=False, picker=True),
}

def sample_values():
    now = int(time.time() * 1000)
    base = dict(type="DOUBLE", label="", displayName="", min=0, max=100, suffix="", unit="",
                decimalFormat="#.#", mappings=[], enumFallbackValue=None, color="", lastUpdated=now)
    return [
        {**base, "index": 0, "value": "23.5", "label": "Temperature", "displayName": "Temperature",
         "max": 50, "suffix": "°C", "color": "#D1FF39"},
        {**base, "index": 1, "value": "62", "type": "INT", "label": "Humidity", "displayName": "Humidity",
         "suffix": "%", "decimalFormat": "#", "color": "#10F17F"},
        {**base, "index": 2, "value": "1", "type": "ENUM", "label": "Mode", "displayName": "Mode",
         "min": None, "max": None, "mappings": ["Off", "Auto", "Manual"]},
    ]

def apply_level(values, level):
    fraction = {"min": 0.0, "mid": 0.5, "max": 1.0}[level]
    for v in values:
        if v.get("type") in ("INT", "DOUBLE") and v.get("min") is not None and v.get("max") is not None:
            v["value"] = str(round(v["min"] + (v["max"] - v["min"]) * fraction, 2))
    return values

MOCK = """
(() => {
  const CFG = __CFG__;
  window.__calls = [];
  const record = (fn, args) => window.__calls.push({ fn, args: Array.from(args) });
  const theme = {
    background: CFG.theme, brand: '#D1FF39FF', primary: '#10F17FFF', positive: '#3FA038FF',
    warning: '#FFC104FF', critical: '#FE1205FF', onBrand: '#03030AFF',
    primaryFont: null, widgetValuesFont: null,
  };
  const series = (from, to, lo, hi) => {
    const n = 48, out = [];
    for (let i = 0; i < n; i++) {
      const x = from + (to - from) * i / (n - 1);
      out.push({ x, y: lo + (hi - lo) * (0.5 + 0.4 * Math.sin(i / 5)) });
    }
    return out;
  };
  window.BlynkBridge = class {
    constructor() {}
    isBridgeAvailable() { return true; }
    isRangePickerSupported() { return CFG.picker; }
    isPageActionsSupported() { return CFG.pages; }
    isExternalRequestsAllowed() { return false; }
    setCallbacks(cb) { window.__cb = cb; }
    setOnErrorEnabled() {} setLogging() {} destroy() {} log() {}
    sendError() { record('sendError', arguments); }
    sendValue() { record('sendValue', arguments); }
    showPage() { record('showPage', arguments); }
    closePage() { record('closePage', arguments); }
    closeAllPages() { record('closeAllPages', arguments); }
    getTheme() { return Promise.resolve(theme); }
    getValues() { return Promise.resolve(CFG.values); }
    getValue(sel) {
      const v = typeof sel === 'number' ? CFG.values[sel] : CFG.values.find(x => x.label === sel.name);
      return v ? Promise.resolve(v) : Promise.reject(new Error('datastream_not_found'));
    }
    getDeviceInfo() {
      return Promise.resolve({ id: 1, orgId: 1, name: 'Demo device', lastReportedAt: Date.now(), status: 'ONLINE' });
    }
    getHistoricalData(o) {
      const to = o.to || Date.now(), from = o.from || to - 864e5;
      return Promise.resolve({ streams: (o.dataStreams || []).map(d => {
        const v = CFG.values[d.index] || {};
        const lo = v.min ?? 0, hi = v.max ?? 100;
        return { index: d.index, granularity: 'HOURLY', values: series(from, to, lo, hi) };
      }) });
    }
    getMapData() {
      const t = Date.now();
      return Promise.resolve({ points: [0, 1, 2, 3, 4].map(i => ({ ts: t - (5 - i) * 6e5, latitude: 50.45 + i * 0.002, longitude: 30.52 + i * 0.003 })) });
    }
    getAllDeviceMetadata() { return Promise.resolve([]); }
    getDeviceMetadata() { return Promise.reject(new Error('no metadata in mock')); }
    updateDeviceMetadata() { return Promise.reject(new Error('no metadata in mock')); }
    getPages() { return Promise.resolve(CFG.mockPages); }
  };
})();
"""

def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("widget")
    ap.add_argument("--out", default=None, help="output PNG (default: <widget>-render.png next to /tmp)")
    ap.add_argument("--variants", default="light-mobile,dark-mobile,light-web")
    ap.add_argument("--size", default="380x300", help="tile size WxH in px")
    ap.add_argument("--level", choices=["min", "mid", "max"], default="mid",
                    help="set numeric datastreams with min/max to this fraction of their range")
    ap.add_argument("--values", help="JSON file with an array of ValueObjects instead of the sample streams")
    ap.add_argument("--pages", help="JSON file returned by the mock getPages() (default [])")
    ap.add_argument("--click", help="CSS selector to click once after load; bridge calls are printed")
    args = ap.parse_args()

    try:
        from playwright.sync_api import sync_playwright
        from PIL import Image, ImageDraw
    except ImportError as e:
        sys.exit(f"Missing dependency ({e}). pip install playwright pillow --break-system-packages")

    width, height = (int(n) for n in args.size.lower().split("x"))
    values = json.load(open(args.values)) if args.values else sample_values()
    values = apply_level(values, args.level)
    mock_pages = json.load(open(args.pages)) if args.pages else []
    names = [n.strip() for n in args.variants.split(",") if n.strip()]
    unknown = [n for n in names if n not in VARIANTS]
    if unknown:
        sys.exit(f"Unknown variant(s) {unknown}; choose from {list(VARIANTS)}")

    url = Path(args.widget).resolve().as_uri()
    out = Path(args.out or Path(tempfile.gettempdir()) / (Path(args.widget).stem + "-render.png"))
    shots, report = [], []

    with sync_playwright() as p:
        browser = p.chromium.launch()
        for name in names:
            v = VARIANTS[name]
            cfg = dict(theme=v["theme"], pages=v["pages"], picker=v["picker"], values=values, mockPages=mock_pages)
            context = browser.new_context(viewport={"width": width, "height": height},
                                          color_scheme=v["os"], has_touch=not v["picker"])
            page = context.new_page()
            errors = []
            page.on("console", lambda m, errors=errors: errors.append(m.text) if m.type == "error" else None)
            page.on("pageerror", lambda e, errors=errors: errors.append(str(e)))
            page.add_init_script(MOCK.replace("__CFG__", json.dumps(cfg)))
            page.goto(url)
            page.add_style_tag(content=f"html{{background:{v['bg']} !important}}")   # stand-in for the host tile
            page.wait_for_timeout(500)
            calls = []
            if args.click:
                try:
                    page.locator(args.click).first.click(force=True, timeout=3000)
                    page.wait_for_timeout(200)
                    calls = page.evaluate("window.__calls")
                except Exception as e:  # selector missing etc.
                    errors.append(f"--click failed: {e}")
            tmp = Path(tempfile.gettempdir()) / f"_rc_{name}.png"
            page.screenshot(path=str(tmp))
            shots.append((name, tmp))
            report.append((name, errors, calls))
            context.close()
        browser.close()

    # One contact sheet, so the whole check costs a single image view.
    label_h, gap = 22, 12
    sheet = Image.new("RGB", (len(shots) * width + (len(shots) + 1) * gap, height + label_h + 2 * gap), "#888888")
    draw = ImageDraw.Draw(sheet)
    for i, (name, path) in enumerate(shots):
        x = gap + i * (width + gap)
        draw.text((x, gap), name, fill="#FFFFFF")
        sheet.paste(Image.open(path), (x, gap + label_h))
    sheet.save(out)

    print(f"contact sheet: {out}")
    for name, errors, calls in report:
        print(f"[{name}] errors: {'; '.join(errors) if errors else 'none'}")
        if args.click:
            print(f"[{name}] bridge calls after click: {json.dumps(calls)}")

if __name__ == "__main__":
    main()
