#!/usr/bin/env python3
"""Validate a Blynk HTML widget against the skill's hard constraints and QA rules.

Usage: python3 validate_widget.py path/to/widget.html
Exit code 0 = no failures (warnings don't fail), 1 = at least one failure.

FAIL = breaks on a host or violates a hard rule. WARN = likely bug; fix it or
be sure it's deliberate. Rule references point at the skill's reference files.
"""
import re
import sys

LIMIT = 100000


def strip_comments(code: str) -> str:
    """Drop /* */ and // comments so explanatory text doesn't trigger checks."""
    code = re.sub(r"/\*.*?\*/", " ", code, flags=re.S)
    code = re.sub(r"(^|[\s;{}(,])//[^\n]*", r"\1", code)
    return re.sub(r"<!--.*?-->", " ", code, flags=re.S)


def scripts_of(html: str) -> str:
    return "\n".join(re.findall(r"<script[^>]*>(.*?)</script>", html, flags=re.S | re.I))


def styles_of(html: str) -> str:
    return "\n".join(re.findall(r"<style[^>]*>(.*?)</style>", html, flags=re.S | re.I))


def media_blocks(css: str, query: str):
    """Yield the inner text of every @media block whose condition contains `query`."""
    for m in re.finditer(r"@media[^{]*" + query + r"[^{]*\{", css):
        depth, i = 1, m.end()
        while i < len(css) and depth:
            depth += {"{": 1, "}": -1}.get(css[i], 0)
            i += 1
        yield css[m.end(): i - 1]


def check(html: str):
    fails, warns = [], []
    n = len(html)
    code = strip_comments(html)
    js = strip_comments(scripts_of(html))
    css = strip_comments(styles_of(html))
    compact_css = re.sub(r"\s+", "", css)

    # ── Size ───────────────────────────────────────────────────────────────
    if n > LIMIT:
        fails.append(f"size {n} chars exceeds the {LIMIT} hard cap (over by {n - LIMIT})")
    else:
        print(f"  size: {n}/{LIMIT} chars  ({LIMIT - n} to spare)")

    # ── Bridge ─────────────────────────────────────────────────────────────
    if not re.search(r"typeof\s+(window\.)?BlynkBridge", js):
        fails.append("missing BlynkBridge fallback stub (no `typeof window.BlynkBridge === 'function'` guard)")
    if re.search(r"isBridgeAvailable\s*:\s*(true|false)\b", js):
        fails.append("stub defines isBridgeAvailable as a boolean — it's a method: `isBridgeAvailable: () => false`")
    for old, new in [("getDeviceMetaFields", "getAllDeviceMetadata"), ("getDeviceMetaField", "getDeviceMetadata"),
                     ("updateDeviceMetaField", "updateDeviceMetadata"), ("onDeviceMetaFieldUpdated", "onDeviceMetadataUpdated")]:
        if re.search(r"\b" + old + r"\b", js):
            fails.append(f"removed API `{old}` — use `{new}`")
    if re.search(r"\.updateDeviceMetadata\s*\(", js):
        if not re.search(r"\beditable\b", js):
            warns.append("updateDeviceMetadata without checking `editable` — only editable fields get an editor "
                         "(bridge-api.md §7)")
        if "enabledFields" not in js and re.search(r"['\"](Contact|Location)['\"]", js):
            warns.append("Contact/Location editing without schema.enabledFields — edit only the enabled properties")
        readonly = [k for k in ("Switch", "Cost", "Range", "Shift", "Coordinates", "Time")
                    if re.search(r"['\"]" + k + r"['\"]", js)]
        if readonly and "EDITABLE" not in js.upper():
            warns.append("editing gated only on `editable` — these types accept no patch: "
                         + ", ".join(readonly) + " (bridge-api.md §7)")
    if "<input" in code and re.search(r"\btype\s*=\s*['\"]text|\.type\s*=\s*['\"]text", code) \
            and "visualViewport" not in js:
        warns.append("text input without visualViewport handling — on iOS, focusing an input scrolls the document "
                     "even with overflow:hidden (platforms.md §5)")
    if re.search(r"\.getConfig\s*\(", js):
        fails.append("`getConfig()` no longer exists — remove it")
    if re.search(r"\blastUpdatedAt\b", js):
        warns.append("`lastUpdatedAt` was renamed to `lastUpdated`")
    if len(re.findall(r"\.setCallbacks\s*\(", js)) > 1:
        warns.append("setCallbacks called more than once — register every callback in the single skeleton call "
                     "(omitted keys are kept, but one call is easier to reason about)")

    # Promise safety (soft).
    if re.search(r"\b(getValues?|getTheme|getHistoricalData|getMapData|getDeviceInfo|getPages|"
                 r"getAllDeviceMetadata|getDeviceMetadata|updateDeviceMetadata)\s*\(", js) and ".catch" not in js \
            and "catch (" not in js and "catch(" not in js:
        warns.append("bridge requests without any rejection handler — every Promise call needs .catch()")
    if re.search(r"\.catch\s*\([^;]{0,120}?sendError\s*\(", js, flags=re.S):
        warns.append("sendError inside .catch — requests already toast their failure; just update widget state "
                     "(bridge-api.md §4)")

    # ── Theme ──────────────────────────────────────────────────────────────
    if "getTheme" not in js:
        fails.append("does not call getTheme() — widget won't follow the app theme")
    elif not re.search(r"setAttribute\(\s*['\"]data-theme['\"]|dataset\.theme\s*=", js):
        fails.append("theme applied without setting data-theme on <html> — light/dark must follow the app theme, "
                     "not the OS (style.md §4)")
    if re.search(r"\bonThemeUpdate\b(?!d)", js):
        fails.append("`onThemeUpdate` is misspelled — the callback is `onThemeUpdated`; it never fires otherwise")
    elif "getTheme" in js and "onThemeUpdated" not in js:
        warns.append("no onThemeUpdated callback — the widget won't react to a live theme switch on web")
    if re.search(r"\.textPrimary\b", js):
        warns.append("theme.textPrimary used — it can carry the brand color; text comes from the text ramp "
                     "(textTitle/textSecondary/neutral via applyTheme, style.md §3)")
    if re.search(r"\b(brand|primary|neutral|positive|warning|critical|onBrand|onPrimary|background)\s*\+\s*['\"][0-9a-fA-F]{2}['\"]", js) \
            or re.search(r"\.slice\(\s*0\s*,\s*7\s*\)\s*\+\s*['\"][0-9a-fA-F]{2}['\"]", js):
        warns.append("alpha appended to a theme color by string concat — breaks on #rrggbbaa/#rgb; use withAlpha(hex, a)")

    # prefers-color-scheme must only be an editor fallback for tokens that the app theme also sets.
    themed_vars = set()
    for m in re.finditer(r"([^{}]*data-theme[^{}]*)\{([^}]*)\}", css):
        if "not([data-theme" not in m.group(1):
            themed_vars.update(re.findall(r"(--[\w-]+)\s*:", m.group(2)))
    themed_vars.update(re.findall(r"setProperty\(\s*['\"](--[\w-]+)", js))
    for block in media_blocks(css, "prefers-color-scheme"):
        media_vars = set(re.findall(r"(--[\w-]+)\s*:", block))
        missing = sorted(media_vars - themed_vars)
        if missing:
            warns.append("set only via prefers-color-scheme, not from the app theme: " + ", ".join(missing[:8])
                         + (" …" if len(missing) > 8 else "") + " — declare them in [data-theme] blocks (style.md §4)")
        for selector in re.findall(r"([^{}]+)\{", block):
            if ":root:not([data-theme" not in selector.replace(" ", ""):
                warns.append(f"prefers-color-scheme block styles `{selector.strip()[:40]}` directly — only redeclare "
                             "tokens under :root:not([data-theme]) (style.md §4)")
                break

    # ── CSS checks ─────────────────────────────────────────────────────────
    for m in re.finditer(r"(--[\w-]+)\s*:\s*var\(\s*(--[\w-]+)\s*[,)]", code):
        if m.group(1) == m.group(2):
            fails.append(f"`{m.group(1)}: var({m.group(2)})` references itself — invalid cycle, fills fall back to black")
    if re.search(r"overscroll-behavior[\w-]*\s*:\s*none", css):
        fails.append("overscroll-behavior:none stops the dashboard from scrolling — remove it")
    if re.search(r"font-family\s*:[^;}]*\bmonospace\b|--font-values\s*:[^;}]*\bmonospace\b", css):
        warns.append("monospace in a font stack — renders as a typewriter font on Android; use "
                     "var(--font-values, system-ui, sans-serif) + tabular-nums unless monospace is deliberate (style.md §6)")
    if re.search(r"text-shadow\s*:(?!\s*none)|drop-shadow\s*\(", css) or \
            re.search(r"box-shadow\s*:[^;}]*\d+px\s+-?\d+px\s+[1-9]\d*px", css):
        warns.append("shadow with blur found — no glows/soft shadows unless the user asked (style.md §9)")

    # ── Iframe reset ───────────────────────────────────────────────────────
    if not re.search(r"html\s*,\s*body[^{]*\{[^}]*margin\s*:\s*0", css, re.I):
        fails.append("missing html,body margin:0 reset")
    if "overflow:hidden" not in compact_css:
        warns.append("no `overflow:hidden` on html/body — dashboard scroll may be hijacked")
    if "text-size-adjust" not in css:
        warns.append("no text-size-adjust:100% in the reset — iOS enlarges text on its own")
    if not re.search(r'<meta[^>]+name=["\']viewport', html, re.I):
        fails.append("missing viewport meta tag")

    # ── External resources ─────────────────────────────────────────────────
    if re.search(r"<script[^>]+src\s*=", code, re.I):
        fails.append("external <script src> found — inline all JS (no CDN)")
    if re.search(r'<link[^>]+href\s*=\s*["\']https?:', code, re.I):
        fails.append("external <link href=\"http…\"> found — no CDN fonts/styles")
    if re.search(r"@import\s+url\(\s*[\"']?https?:", css, re.I) or re.search(r"url\(\s*[\"']?https?:", css, re.I):
        fails.append("external url(http…) in CSS — no remote fonts/images")
    if re.search(r'<img[^>]+src\s*=\s*["\']https?:', code, re.I):
        fails.append("remote <img src> — inline images as SVG or data: URIs")
    if re.search(r"\bfetch\s*\(", js) and "isExternalRequestsAllowed" not in js:
        warns.append("fetch() without an isExternalRequestsAllowed() guard")

    # ── Platform capabilities ──────────────────────────────────────────────
    if "RANGE_PICKER" in js:
        if "isRangePickerSupported" not in js:
            fails.append("RANGE_PICKER used without an isRangePickerSupported() guard — fails on mobile")
        if "CUSTOM" not in js:
            warns.append("RANGE_PICKER without a CUSTOM fallback — mobile has no dashboard picker; render the in-widget "
                         "period picker (platforms.md §2)")
        if "onHistoricalDataUpdated" not in js and "onMapDataUpdated" not in js:
            warns.append("RANGE_PICKER without onHistoricalDataUpdated/onMapDataUpdated — later picker changes are lost")
    if re.search(r"\.(showPage|closePage|closeAllPages)\s*\(", js) and "isPageActionsSupported" not in js:
        fails.append("page navigation without an isPageActionsSupported() guard — pages exist only in the mobile app")

    # ── Values, numbers, dates ─────────────────────────────────────────────
    if re.search(r"\b(?:Number\.)?(parseFloat|parseInt)\s*\([^)]*\b(value|min|max)\b", js):
        warns.append("parseFloat/parseInt on a bridge value — locale strings like \"4,758\" parse as 4; use toNumber()")
    if re.search(r"\.type\s*[!=]==?\s*['\"](int|double|string|enum|location|unknown)['\"]", js):
        warns.append("lowercase datastream type comparison — types are uppercase (INT, DOUBLE, ENUM…)")
    if re.search(r"\btoLocale(Date|Time)?String\s*\(|\bIntl\.(DateTimeFormat|NumberFormat)", js):
        warns.append("toLocale*/Intl formatting — use the fixed formats (18 Sep 2026, 14:00) and formatNumber (style.md §8)")
    if re.search(r"Math\.ceil\(\s*[\w.]+\s*/\s*[\w.]+\s*\)\s*\*\s*[\w.]+", js):
        warns.append("Math.ceil(x/step)*step tick alignment is UTC-based — use timeTicks()/localFloor (style.md §8)")

    # ── Controls & charts ──────────────────────────────────────────────────
    if re.search(r"type\s*=\s*['\"](date|time|datetime-local)['\"]", code) and "text-fill-color" not in css:
        warns.append("native date/time input shows the platform's own format — hide its text and overlay a label "
                     "(style.md §7, createDateField)")
    if "<select" in code and not re.search(r"appearance\s*:\s*none", css):
        warns.append("<select> without appearance:none — styles differ per platform (style.md §7)")
    if "getHistoricalData" in js and re.search(r"pointerenter", js):
        warns.append("pointerenter in a chart — doesn't fire during touch drags; use attachScrub (components.md → Chart)")

    # ── Safety ─────────────────────────────────────────────────────────────
    if "innerHTML" in js:
        warns.append("innerHTML used — prefer textContent/setAttribute for bridge values")

    return fails, warns


def main():
    if len(sys.argv) != 2:
        print("usage: validate_widget.py path/to/widget.html")
        sys.exit(2)
    with open(sys.argv[1], encoding="utf-8") as f:
        html = f.read()

    fails, warns = check(html)

    for w in warns:
        print(f"  WARN: {w}")
    if fails:
        print("\nFAIL:")
        for fl in fails:
            print(f"  - {fl}")
        sys.exit(1)
    print("\nPASS: all hard constraints satisfied." + (" Review the warnings above." if warns else ""))
    sys.exit(0)


if __name__ == "__main__":
    main()
