#!/usr/bin/env python3
"""Print one '## ' section of a reference file, or list its sections.

Usage:
  python3 read_section.py references/platforms.md            # list sections
  python3 read_section.py references/platforms.md 3          # section numbered "3."
  python3 read_section.py references/style.md "baseline"     # first heading containing the text

Why: the reference files are long, and most widgets need one or two sections.
"""
import re
import signal
import sys

signal.signal(signal.SIGPIPE, signal.SIG_DFL)   # quiet when piped into head


def split_sections(text):
    """Return [(heading, body_lines)]; '## ' inside code fences is not a heading."""
    sections, current, in_fence = [], None, False
    for line in text.splitlines():
        if line.lstrip().startswith("```"):
            in_fence = not in_fence
        if not in_fence and line.startswith("## "):
            current = (line[3:].strip(), [line])
            sections.append(current)
        elif current is not None:
            current[1].append(line)
    return sections


def main():
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    sections = split_sections(open(sys.argv[1], encoding="utf-8").read())
    if len(sys.argv) == 2:
        for heading, body in sections:
            print(f"{len(body):4d} lines  {heading}")
        return

    query = " ".join(sys.argv[2:]).strip().lower()
    for heading, body in sections:
        numbered = re.match(r"(\d+)\.", heading)
        if (numbered and numbered.group(1) == query) or (not query.isdigit() and query in heading.lower()):
            print("\n".join(body).rstrip())
            return
    sys.exit(f"No section matching '{query}'. Run without a query to list sections.")


if __name__ == "__main__":
    main()
