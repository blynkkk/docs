# Style & Theming

Every rule below that isn't marked as a baseline default fixes a bug that shipped on web, iOS or Android. Where the user explicitly asks for something different, follow the user — except for contrast and visibility, which always hold.

## Contents
1. Priority order
2. Theme → CSS tokens
3. Text colors (luminance ramp)
4. Light/dark follows the app, not the OS
5. Non-text parts (≥ 3:1)
6. Fonts
7. Native form controls
8. Dates, times, numbers on screen
9. Blynk baseline (cards, radius) & palette
10. Layout
11. Visual check before presenting

---

## 1. Priority order

1. **Explicit user style or a pasted screenshot** — match it.
2. **The reference sheet** for the chosen component (`assets/refs/*.webp`).
3. **Blynk baseline** (§9: rounded cards with filled blocks) when nothing else is specified.

## 2. Theme → CSS tokens

`applyTheme(theme)` (in the skeleton) sets `data-theme` on `<html>` (§4) and writes these theme fields as custom properties; control colors come from the `[data-theme]` token blocks, so one attribute flips the whole widget.

| Theme field | CSS var | Use |
|---|---|---|
| `brand` | `--brand` | Primary accent: fills, active state, focus, series. **Never text on the widget background** |
| `primary` | `--primary` | Secondary accent. Never text |
| `positive` / `warning` / `critical` | `--positive` / `--warning` / `--critical` | Status fills, dots, badges, threshold bands |
| `background` | → `data-theme`, `--surface` | Decides light/dark. `--surface` is only for opaque overlays (tooltips, popovers); the widget itself stays transparent |
| `onBrand` | `--on-brand` (fallback `#03030A`) | Text/icons on a brand fill |
| `primaryFont` | `--font-primary` | All UI text, inputs, placeholders, selects, buttons |
| `widgetValuesFont` | `--font-values` | Numeric/main values only |
| `textTitle` / `textSecondary` / `neutral` / `textEmphasis` | text ramp | See §3 |

Translucent variants go through `withAlpha(hex, a)` — it normalizes `#rgb` / `#rrggbbaa` first. Never append hex digits (`theme.brand + '26'`, `theme.neutral + '40'`).

The complete token block is in `assets/skeleton.html`; keep it as is. It also declares four tokens no theme field feeds: `--card` and `--block` (surface fills, per mode) and the radii `--radius-card` / `--radius-block` (§9).

Add a new mode-dependent token? Declare it in **both** `[data-theme]` blocks and the media fallback.

## 3. Text colors (luminance ramp)

`applyTheme` fills the ramp from the theme when the host sends the field (web); otherwise these values apply, chosen from the luminance of `theme.background` (mobile):

| Token (theme field) | Light | Dark | Use for |
|---|---|---|---|
| `--text-primary` (`textTitle`) | `#03030A` | `#FFFFFF` | Headers, titles, subtitles, main/numeric values, selected-state text |
| `--text-secondary` (`textSecondary`) | `#5F5F66` | `rgba(255,255,255,.7)` | Descriptions, labels, units, axis labels, tooltip body |
| `--text-muted` (`neutral`) | `#6E6E75` | `rgba(255,255,255,.5)` | Captions, placeholders, empty/loading states, "--" |

`textEmphasis` → `--text-emphasis`, used as `var(--text-emphasis, var(--text-primary))`. **`textPrimary` is never used for text** — it can carry the brand color. Despite the similar name, `--text-primary` comes from `textTitle`.

- These pass 4.5:1 on white and on the `#f7f7f8` / `#1c1c1f` dashboards. Never go lighter in light mode or lower opacity in dark mode for any text — that includes disabled states (show disabled with `--text-muted` + `cursor: default`, not with opacity on text).
- `brand` / `primary` / status colors are **never** text colors on the widget background. Status is carried by a dot, badge fill or bar; its label stays in the text ramp.
- Text *on* a brand fill uses `--on-brand`.
- A selected chip/tab/segment is either **brand fill + `--on-brand` text**, or **`--text-primary` outline + `--text-primary` text**. Never brand-colored text.

## 4. Light/dark follows the app, not the OS

The Blynk app theme and the device's OS setting are independent (a Mac in light mode can show a dark dashboard). A color chosen by `@media (prefers-color-scheme)` and not reset from the app theme shows the wrong mode — this shipped as wrong input borders, a wrong switch track and an invisible slider handle.

- `applyTheme` sets `data-theme` from `isDark(theme.background)`.
- Every mode-dependent value lives in `:root[data-theme="dark"]` / `[data-theme="light"]` tokens. `prefers-color-scheme` exists **only** as the editor fallback, guarded with `:root:not([data-theme])`, and only redeclares tokens — never style components inside it.
- **Every variable declared inside a `prefers-color-scheme` block must also be set from the app theme.** The validator warns otherwise.
- The live-theme callback is **`onThemeUpdated`** (one preset shipped `onThemeUpdate` and never reacted). The validator errors on the misspelling.

## 5. Non-text parts (≥ 3:1)

Switch tracks, input borders, focus rings and gauge tracks must stay visible against what surrounds them, in both modes and at every value.

| Part | Light | Dark |
|---|---|---|
| Input / field border `--field-border` | `#E5E5EA` | `#5A5A62` (never `#2A2A2F` — it disappears) |
| Switch off-track `--switch-off` | `#D3D3D6` | `#000000` (grey blends into dark backgrounds) |
| Slider handle `--handle` | `#56565C` | `#F2F2F4` + `box-shadow: var(--handle-edge)` (`0 0 0 1px rgba(0,0,0,.45)`), so it stays visible over the brand fill too |
| Divider / chart gridline `--divider` | primary text ~12% | primary text ~15% |
| Focus ring | `2px solid var(--text-primary)` | same |
| Gauge / level track | `--divider` or `--switch-off` | same tokens |

Test every control at **min, mid and max** in both themes before presenting.

## 6. Fonts

- UI text — labels, titles, **inputs, placeholders, selects, buttons, chips** — uses `font-family: var(--font-primary, system-ui, sans-serif)`. A placeholder like "Enter value…" is text, not a value.
- Values use `font-family: var(--font-values, system-ui, sans-serif); font-variant-numeric: tabular-nums;`. **No `monospace` fallback** — Android renders it as a typewriter font.
- Theme fonts (may arrive late, may be `null`) can fail to load in the mobile WebView, falling back to SF / Roboto. Expected — keep the system fallback, no CDN fonts.

## 7. Native form controls

Native controls look and format differently per platform — never rely on them for *display*.

- **`<input type="date">` / `type="time"`** show their value in the platform's own format (web `18.09.2026`, iOS `18 Sep 2026` centered, Android `09/18/2026`), and CSS can't change it. Hide the native text (`color: transparent; -webkit-text-fill-color: transparent;` + `::-webkit-datetime-edit { opacity: 0 }`), draw your own left-aligned label on top (`pointer-events: none`), keep the native input underneath so each platform keeps its picker, call `input.showPicker()` on click for desktop, and keep a `min-height` so iOS doesn't collapse an empty field. Ready-made: `createDateField` in `platforms.md` §6.
- **`<select>` and number inputs:** `appearance: none`, style them with the tokens and `--font-primary`.

## 8. Dates, times, numbers on screen

- **One fixed, unambiguous date format everywhere**, built by hand — never `toLocaleDateString`, `toLocaleTimeString`, `toLocaleString` or `Intl` defaults: `18 Sep 2026`, `18 Sep 14:00`, `14:00`, `Sep 2026`. 24-hour, zero-padded. Formatters in `platforms.md` §5.
- **Tooltip precision follows the data's bucket, not the range length:** hourly bars show date + time even in a 7-day view; daily/weekly show the date; monthly shows `Sep 2026` (`bucketLabel`).
- **Tooltip time = start of the bucket on the local clock** (`bucketStart`, so `08:05` shows as `08:00`). Missing `granularity` → `inferGranularity`.
- **Axis ticks on round local times**, not UTC — use `timeTicks(from, to, maxTicks)`.
- **Numbers:** `toNumber()` for `value`, `min`, `max`, then `formatNumber(n, decimalFormat)`. No `toLocaleString`.

## 9. Blynk baseline (cards, radius) & palette

Baseline default when no user style or reference applies. Aesthetic: **rounded cards that hold filled blocks**, high contrast, dense purposeful layout, solid borders and fills instead of shadows, **uppercase labels with wide letter-spacing**, **bold values with tabular digits**.

### Cards, blocks and radius

Two radii and two surface fills, all tokens in the skeleton. Keeping to two of each makes widgets sit together on one dashboard, so don't invent a third.

| Element | Radius | Surface |
|---|---|---|
| **Card** — the outer surface that groups related content | `--radius-card` (16px) | `--card`: **white in the light theme**, a faint tint in dark; `1px solid var(--divider)` border |
| **Block** — a region inside a card (a value cell, a chart area, a group of rows) | `--radius-block` (8px) | `--block`: **filled by default**, no border |
| Small controls: buttons, chips, inputs, selects, tooltips | `--radius-block` (8px) | as the control needs |
| Switch tracks, slider and level tracks, status dots, pill badges | `999px` — the shape is the control | |
| Data marks: chart bars and lines, gauge arcs, map paths | whatever the data needs; never the card radius | |

- Group related content into cards, and put the sub-structure inside a card as filled blocks. The card's border is subtle (`--divider`), so a white card still reads on a light-grey dashboard.
- A framed block (transparent, `1px solid var(--divider)`) is the exception: use it only when the user asks, or when a filled block would disappear against its surroundings.
- The tile stays transparent with no outer padding (the host draws it), so the outermost card sits flush against the tile edges. Cards have inner padding of at least 12px.
- The pairing is fixed: 16px cards, 8px blocks inside them. Don't scale the inner radius with padding.
- Separate things with fills and borders, not soft shadows. `overflow: hidden` on a card only when a child must follow its corner (an edge-to-edge chart or list).
- The reference sheets in `assets/refs/` show layout, hierarchy and color. Their corners may be square and their surfaces may differ; take the radius and surfaces from this section unless the user asks otherwise.

```css
.card  { background: var(--card); border: 1px solid var(--divider); border-radius: var(--radius-card); padding: 16px; }
.block { background: var(--block); border-radius: var(--radius-block); padding: 12px; }
.chip, .button, .field { border-radius: var(--radius-block); }
.track { border-radius: 999px; }
```

**Never add a glow** (`box-shadow` / `text-shadow` / `filter: drop-shadow()` used as a halo, neon bloom or aura) unless the user explicitly asks for one. This holds even when matching a reference sheet or screenshot. (The 1px `--handle-edge` outline is an edge, not a glow.)

Palette (editor fallbacks and accents — live widgets use the theme):
- Black `#000` / `#03030A`, white `#fff` — the main colors, with all shades of black. Color is for accents and for the elements that need attention (e.g. a level bar's fill).
- Brand neon green-yellow `#D1FF39` / `#C8FF1A`; primary neon green `#10F17F`
- Blue `#0000FE`, cyan `#3AF1F5`, deep blue `#3100FF`, secondary blue `#0000FF`
- Hot pink `#FC00B1`, light pink `#FF70FE`, violet `#8300E8`
- Warning yellow `#FFC104`, orange `#FF9C14`, brick `#BD4B04`, salmon `#FF9A61`
- Critical red `#FE1205`, dark red `#9B1005`; positive green `#3FA038`
- A datastream's own `color` field is a good per-series accent in multi-stream charts.

## 10. Layout

- 4-point grid for spacing.
- The tile can be any size → `container-type: size` on `.stage` and `@container` queries for compact vs roomy. Container units (`cqw/cqh/cqmin/cqmax`) work; fluid type like `clamp(12px, 5cqmin, 28px)`.
- **No outer padding** on `.stage` or a top-level wrapper — the host container already pads. Inner spacing is fine.
- Content that can exceed the tile scrolls **inside** a region (`flex: 1; min-height: 0; overflow-y: auto; overflow-x: hidden`); `html, body` stay `overflow: hidden`. See `platforms.md` §4.

## 11. Visual check before presenting

Run `python3 scripts/render_check.py widget.html`. In one call it renders the widget in the **light and dark app themes** (each with the OS in the opposite mode) and on the web path, and stitches them into **one image** to view once. Add `--level min|mid|max` to test controls at each end, and `--values file.json` for your own datastreams.

Check every text against §3, every non-text part against §5, dates/numbers against §8, and radii against §9. For history widgets the web variant shows the range-picker path and the mobile variants show the in-widget chips with an axis spanning the chosen window.
