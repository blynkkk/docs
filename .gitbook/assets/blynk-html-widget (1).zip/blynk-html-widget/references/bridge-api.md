# BlynkBridge API Reference

The host injects `BlynkBridge` before your scripts. All hosts share the API, but capabilities differ — see `platforms.md`. Public guide (source of truth for anything newer): https://docs.blynk.io/en/blynk.console/widgets-console/html-widget/html-widget-developer-guide

## 1. Construction

```js
const bridge = new window.BlynkBridge({ logEnabled: true, isOnErrorEnabled: true });
bridge.isBridgeAvailable();   // true inside a host, false in the browser/editor
bridge.destroy();             // only when the page tears its UI down
```

- Guard with `typeof window.BlynkBridge === 'function'`; otherwise use the skeleton's stub.
- Reads and requests return Promises; `sendValue`, `sendError`, `setCallbacks`, page navigation and capability checks are synchronous.
- Don't replace the bridge's `window.blynk*` globals — use `setCallbacks`. There is no `getConfig()`.
- Newer methods (`getMapData`, `getPages`, `*DeviceMetadata`, selectors) can be missing on older hosts — check `typeof bridge.getPages === 'function'` when a widget depends on one.

## 2. Values

```js
bridge.getValue(index)   // → Promise<ValueObject>; rejects when the index is out of range
bridge.getValues()       // → Promise<ValueObject[]> in configured order; [] = none configured
```

`index` is the 0-based position in the widget settings — keep each payload's own `index`, never renumber. `getValues()` is a network call: show a loading state and `.catch()`.

| Field | Type | Notes |
|---|---|---|
| `index` | number | 0-based position |
| `value` | string or **null** | Parse with `toNumber()` |
| `type` | uppercase string | `INT`, `DOUBLE`, `STRING`, `ENUM`, `LOCATION`, `UNKNOWN` |
| `label`, `displayName` | string (`''`) | Show `displayName`; name selectors match `label` |
| `min`, `max` | number or **null** | Handle null |
| `suffix`, `unit`, `decimalFormat` | string (`''`) | `suffix` is the display text (`°C`), `decimalFormat` e.g. `#.##` |
| `mappings`, `enumFallbackValue` | string[], string or null | ENUM labels, label for an unmapped index |
| `color` | string (`''`) | Series/accent color, never text |
| `lastUpdated` | number (ms) or null | |

- **Numbers:** `formatValue(v)` in the skeleton does `toNumber` → `formatNumber(n, decimalFormat)`; show the suffix in its own span; null → `--`.
- **ENUM:** `value` is the option **index as a string**; label = `mappings[index] ?? enumFallbackValue ?? value`. Send the index string back.
- **LOCATION:** coordinates come from `getMapData` (§8). **UNKNOWN:** raw string, read-only.
- Name: `streamName(v)` → `displayName || label || 'Datastream N'`.

## 3. Selectors and sending

```js
bridge.getValue({ name: 'Temperature' });   // exact label; or { id: 42 }
bridge.sendValue(index, '23.5');            // or a selector; synchronous
```

- Selectors search only the widget's assigned streams; use the returned `index` for history/map requests.
- Errors: `datastream_not_found`, `ambiguous_datastream_selector` (use `id`), `invalid_selector`. Selector `sendValue` **throws** → `try/catch`.
- Reflect the confirmed state from `onValueUpdated` rather than assuming a write succeeded.

## 4. Callbacks and errors

```js
bridge.setCallbacks({                  // once, before the first read
  onValueUpdated: v => { /* merge by v.index */ },
  onError: message => {},
  onThemeUpdated: applyTheme,          // trailing "d"
  onHistoricalDataUpdated: data => {}, // web RANGE_PICKER pushes
  onMapDataUpdated: data => {},        // web RANGE_PICKER pushes
  onDeviceMetadataUpdated: descriptor => {},
});
```

- Android emits only value, metadata and error callbacks — refetch history yourself on mobile.
- An `async` callback's rejected Promise isn't caught — handle errors inside it.
- Every Promise request already toasts its own failure before rejecting. In `.catch()` only update the widget state; don't call `sendError` again.
- Metadata failures reject with `BlynkBridgeError` — branch on `error.code`, not the message.
- `bridge.log(text)` for debugging.

## 5. Theme

`bridge.getTheme()` → Promise of the theme; colors are `#rrggbbaa`, already resolved for the host's light/dark mode. Fonts (`primaryFont`, `widgetValuesFont`, … — may be null) come with it. `applyTheme` in helpers maps everything onto CSS tokens — how each field is used: `style.md` §2–3. Translucent variants: `withAlpha(hex, a)`, never string concatenation.

## 6. Device info

```js
bridge.getDeviceInfo();   // → Promise<{ id, orgId, name, lastReportedAt, status? } | null>
```
`null` = no device linked. `status` is `'ONLINE'`, `'OFFLINE'` or custom — compare `toUpperCase()`. The status dot takes `--positive` / `--critical`; the status text stays in the text ramp.

## 7. Device metadata

```js
bridge.getAllDeviceMetadata(options?);              // → Promise<descriptor[]> for the bound device
bridge.getDeviceMetadata(selector, options?);       // selector: { id } (preferred) or { name }
bridge.updateDeviceMetadata(selector, valuePatch);  // → Promise<committed descriptor>
// setCallbacks({ onDeviceMetadataUpdated: descriptor => {} }) — merge by id
```

Descriptors carry `{ id, type, label, editable, disabled, displayValue, value, schema }`; `value` is
always an object, and `displayValue` is usually null, so format from `value`. The old
`getDeviceMetaFields` / `updateDeviceMetaField` / `onDeviceMetaFieldUpdated` names are gone (the
validator fails on them). `{ refresh: true }` forces an authoritative read.

**Building a metadata widget? Read `references/metadata.md` first** — the value shapes, which types
accept a patch, the patch format per type, and the write/timeout rules are all there, and guessing
them wastes a build. **Skip it entirely for datastream-only widgets.**

## 8. History and map data

```js
bridge.getHistoricalData({ period, from, to, dataStreams: [{ index, sourceType: 'AVG' }] });
// → { streams: [{ index, granularity, values: [{ x: ms, y }] }] }
bridge.getMapData({ index, period, from, to });
// → { points: [{ ts, latitude, longitude }] }
```

- `period`: `ONE_HOUR`, `SIX_HOURS`, `DAY`, `WEEK`, `MONTH`, `THREE_MONTHS`, `SIX_MONTHS`, `ONE_YEAR`, `CUSTOM`, and `RANGE_PICKER` **only where `isRangePickerSupported()`** (web).
- `CUSTOM`: `from`/`to` as ms numbers, `≤ 365 days` apart (maps need `from < to`).
- History: up to 10 `dataStreams`; `sourceType` `RAW_DATA`, `MIN`, `MAX`, `AVG`, `SUM`, `COUNT`. Missing/null `granularity` → `inferGranularity(values)`.
- `RANGE_PICKER` is a subscription: the Promise resolves with the current window, later picker changes push to `onHistoricalDataUpdated` / `onMapDataUpdated`.
- Timeout 60 s — plan loading, empty, error and timeout states.

## 9. Pages and capability checks

```js
bridge.isRangePickerSupported();   // web: dashboard picker drives history
bridge.isPageActionsSupported();   // mobile: page navigation works
bridge.showPage(index);            // this widget's configured target, 0-based
bridge.closePage();  bridge.closeAllPages();
bridge.getPages();                 // → Promise<[{ id, name }]>, display only
```

Navigation is fire-and-forget. Page `id`s from `getPages()` are **not** `showPage` arguments. Rules for web: `platforms.md` §3.
