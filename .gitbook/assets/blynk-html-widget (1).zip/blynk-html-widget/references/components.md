# Component Recipes

The families below are the common cases, not a closed set — compose or invent when a need doesn't fit. For each, study the matching `assets/refs/*.webp` (when there is one) before writing CSS, then build on the SKILL.md skeleton. Helpers referenced here are in the skeleton or `platforms.md` §6; colors come from the tokens in `style.md` §2.

## Contents
- Gauge · Slider · Switch / button / selector · Value / label card · Horizontal level
- Chart (history)
- Map / location track
- Device metadata card (also read `metadata.md`)
- Page navigation (mobile only)

---

## Gauge — `gauges.webp` (read)
A single bounded numeric value as a radial/arc/semicircle dial or ring; big centered value + label.
- Fields: `min`, `max`, `value`, `suffix`, `decimalFormat`, `displayName`. `min`/`max` can be null → fall back to 0–100.
- Geometry: inline SVG. Sweep = `(toNumber(value) − min) / (max − min)` clamped to [0,1]. `stroke-dasharray`/`stroke-dashoffset` on an arc path, or track + progress circles. Track = `--divider` (or `--switch-off`), progress = `--brand` or a status color.
- Value text inside the gauge is `--text-primary` (it sits on the transparent center, not on the arc).
- Variants: full ring with % center, ~270° open gauge, segmented tick gauge, thin arc with avg marker.
- Multiple streams → small multiples or a labelled grid.

## Slider — `slider.webp` (write)
- Fields: `min`, `max`, `value`, `suffix`. Render from the initial value; on release `sendValue(index, newValue)`.
- Pointer events + `setPointerCapture`; `touch-action: pan-y` on the track (horizontal) or `pan-x` (vertical). Show the live value large while dragging; send on `pointerup`/`change`, not every move.
- Handle: `background: var(--handle); box-shadow: var(--handle-edge)`. Track: `--switch-off`/`--divider`; fill: `--brand`.
- Check min / mid / max in both themes: at max the handle sits fully on the fill, at min fully on the track. Keep the handle **inside the tile** at both ends — inset its travel by its width: with a unitless `--p` (0–1) set from JS, `left: calc((100% - 8px) * var(--p))` for an 8px handle — or `html, body { overflow: hidden }` clips it in half.
- Variants: vertical track with tick scale, horizontal split fill, thermostat dial column.
- Multiple streams → one labelled slider per assigned stream.

## Switch / button / selector — `Buttons_swicthes.webp` (write)
Anything tapped to set a value, pick a mode, fire an action, or step a number.
- **Binary toggle:** track off = `--switch-off`, on = `--brand`; thumb high-contrast on both (white/`--handle`). `sendValue(index, on ? '1' : '0')` (or what the stream expects). Reflect the confirmed state from `onValueUpdated`.
- **ENUM / segmented selector:** options from `mappings[]`; current = `toNumber(value)`; send the chosen index string. Selected segment = brand fill + `--on-brand` text, or `--text-primary` outline + `--text-primary` text — never brand text.
- **Action / preset / stepper buttons:** each tap sends a fixed value; presets highlight the one matching the current value; a stepper clamps to `min`/`max`.
- Buttons and chips use `--font-primary`.
- Multiple streams → one control per stream, labelled.

## Value / label card — `LABEL_CARD_VALUE.webp` (read)
Current value(s) with no time axis; the default when no range or trend is implied.
- One stream → big value (`--font-values`, `tabular-nums`, `--text-primary`) + suffix (`--text-secondary`) + label (`--text-secondary`) + optional device status badge.
- Several streams → a grid of cards (`--radius-card`, 2×2 etc.), each with label + value; put a card's sub-parts in filled blocks (style.md §9). Accents (a colored bar or dot, the stream's `color`) — never colored value text.
- Good for STRING, ENUM label and unbounded numbers. `lastUpdated` can feed a muted "updated 14:05" caption (fixed format).

## Horizontal level — `horizontal_level.webp` (read)
Progress / fill / % of capacity.
- Fill width = clamped `(value − min)/(max − min)`; track `--divider`/`--switch-off`, fill `--brand` or a threshold status color.
- Threshold markers: 1px `--text-primary` ticks, labels in `--text-secondary`.

## Chart — `CHARTS.webp` (read, uses history)
Any "over time / history / trend" need. Uses `getHistoricalData`, not `getValues`.

**Data & window**
- Web vs mobile split (range picker vs in-widget chips + custom range, `RANGE_PICKER` vs `CUSTOM`) → `platforms.md` §2. Follow it exactly.
- `sourceType` `AVG` by default; `RAW_DATA` for dense raw points; `SUM`/`COUNT` for totals.
- X domain: on mobile the **requested** `from…to`; on web the data extent. Y: auto-scale to data min/max with a little headroom; 0-based for bars and totals.
- Up to 10 streams per request; multiple streams → overlaid series (series color = stream `color` or accents) with a small legend, or stacked mini-charts.
- States: loading, empty ("No data for this period"), error ("Could not load data" — the bridge already toasted), 60 s timeout. All in `--text-muted`.

**Axes & guides**
- Ticks: `timeTicks(from, to, maxTicks)` — round local times, no repeated labels; `maxTicks` ≈ 6 roomy, 3 when the chart is ≤ ~200px wide. Axis labels `--text-secondary`, `--font-primary`.
- A **vertical dashed guide at every x-axis label**: `stroke: var(--divider); stroke-width: 1; stroke-dasharray: 2 4`, drawn behind the data. With gaps in the data the chart still reads as a full timeline. Don't add an extra unrounded "range start" label.
- Horizontal gridlines optional, `--divider`.

**Tooltip (scrubbing)**
- `attachScrub(hitRect, { indexAt, show, hide })`: one transparent `<rect>` over the plot area, bar/point picked from pointer x, pointer capture, `touch-action: pan-y`. On touch the tooltip stays on the last item after lifting; on mouse it hides on leave. Never per-bar `pointerenter` (doesn't fire during a touch drag).
- Tooltip text: time = `bucketLabel(x, granularity)` (bucket start, local clock, precision by bucket) in `--text-secondary`; value = `formatNumber` + suffix in `--text-primary`. The tooltip sits over bars, so give it an opaque panel: `background: var(--surface); border: 1px solid var(--field-border)` — never bare text over the data. Clamp it inside the chart's width.

**Robustness**
- Chart container `overflow: hidden`; SVG `width: 100%; height: 100%` with a `viewBox` recomputed on resize (`ResizeObserver`).
- Wrap drawing in `try/catch` and show "Could not draw chart" instead of a blank area.

## Map / location track — no reference sheet (read, uses map data)
- Find the `LOCATION` stream (`v.type === 'LOCATION'`, or a name selector); none → "Assign a location datastream". Data: `getMapData`, window split as in `platforms.md` §2.
- No map tiles (external resources are banned): draw the track as an inline SVG polyline in `--brand`, scaled to fit the box, latest point as a solid dot.
- Caption with the latest fix: `50.4501, 30.5234 · 18 Sep 14:05` in `--text-secondary`.

## Device metadata card — no reference sheet (read, edit where the type allows)
The device's metadata as cards — identity, location, contacts, configuration. **Read `metadata.md` first**: value shapes, which types accept a patch, patch formats. This section is layout and behavior.
- Data: `getAllDeviceMetadata()`; merge `onDeviceMetadataUpdated` pushes by `id`. Log the raw descriptors once (`bridge.log(JSON.stringify(list))`) — the Testing tab console is how you learn a template's real shapes.
- Tile per field: `d.label` in `--text-secondary` uppercase, value in `--text-primary`. Group into Identity / Location / Contacts / Configuration; Location, Contact, Time Zone and Range span the full row.
- Display by normalized `type` (lowercase, letters only), formatting from `value`:
  - **Location** → `siteName` as the bold title, address and coordinates as grey lines beneath, then premises cells (`buildingName`, `floorName`, `unit`, `room`, `zone`). Use the **same key list for display and editing** — a mismatch makes a cell vanish silently instead of erroring. `orgLocationId` / `placeId` are bookkeeping; never show them.
  - **Contact** → initials avatar + name, then email / phone / address lines, each with its own copy button.
  - **Number / Measurement** → big value + unit, min/max bar when limits exist. Unit key is `unit` (Number) or `units` (Measurement) and may be a NAME (`Celsius`, `Inch`) — map common names to symbols.
  - **Cost** → `price` + `currency`; the "per N units" line only when `units` is real (skip `None`) and the quantity (`perValue`) isn't 1.
  - **Time** → `HH:MM` + a mark on a 00–24 track; **Range/Shift** → `from – to`, duration, and a 24-h bar that wraps past midnight.
  - **Switch** → the selected label from `schema.from` / `schema.to` (`value.value` is `"0"`/`"1"`) as plain text, bigger and semi-bold; **List** → the selected option, same styling.
  - **Imei / ICCID / DeviceEui** → values font; **Coordinates, DeviceReference, Table** → one compact line.
- Editing (patchable types only — see `metadata.md`):
  - Small "EDIT" button (`--radius-block`) in the tile header; on desktop the whole tile opens the editor, on touch only the button does (tapping the value copies it).
  - Controls: text input; `inputmode="decimal"` for numbers; **`<select>` for List and Tz** (segments break with many options, and a List must never be free text); one input per `enabledFields` entry for Contact; for Location the site name, address, lat/lon pair and enabled premises.
  - Inputs need `user-select: text` (the reset disables selection on `body`) and `--font-primary`; **16px on touch** and the keyboard handling in `platforms.md` §5.
  - Save / Cancel; Enter saves, Escape cancels. While saving, disable controls and label the button "Saving…". Errors stay inline ("Not saved · code") — the host already toasts.
  - Redraw **only the edited tile**, keeping its screen position; a full re-render moves the list under the user. Keep the open editor's node across pushes so typing isn't wiped.
- Loading: the widget runs in four contexts and only the real dashboard answers fast. Show "Loading…", and after ~1s with no answer show a demo set rather than leaving a blank widget for the host's ~10s timeout. An empty list also means preview → demo. Replace the demo the moment real data or a push arrives, clearing it first so the two never mix, and **restore the real `updateDeviceMetadata`** when leaving demo mode or later edits silently apply locally only. A rejected request gets one plain line. Demo data: label each card with its metadata TYPE and use obviously fake values, so the preview reads as a catalogue of types.

## Page navigation — no reference sheet (mobile only)
Opening the mobile app's custom pages, going back, or returning home.
- `showPage(targetIndex)` (a target configured on this widget), `closePage()`, `closeAllPages()` — all guarded by `isPageActionsSupported()`. Rules for web degradation, labels and `getPages()` are in `platforms.md` §3.
- Visual: rows or tiles with a chevron (`›`) inside a card, label in `--text-primary`, optional description in `--text-secondary`; pressed state on `pointerdown`. Back/home as a compact bar.
- Often combined with another family (a gauge with a "details ›" row) — then the row simply isn't rendered on web.

