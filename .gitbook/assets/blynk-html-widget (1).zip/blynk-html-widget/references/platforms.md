# Web vs mobile

The same HTML file runs on the **web dashboard** and inside the **Android and iOS apps**. The bridge API is shared, but some features exist on only one side. Write one widget that works everywhere by branching on **capability checks**, never on the host name or user agent.

## Contents
1. What differs
2. History & date ranges — web range picker vs in-widget picker
3. Page navigation — mobile only
4. Gestures, scrolling and touch
5. Text input and the iOS keyboard
6. History helper code (dates, ticks, scrubbing, period picker)

---

## 1. What differs

| Capability / behavior | Web dashboard | Android / iOS app | Check |
|---|---|---|---|
| Dashboard date-range picker drives history | ✅ `RANGE_PICKER` | ❌ widget draws its own picker | `isRangePickerSupported()` |
| Custom pages: open / back / home | ❌ no pages | ✅ `showPage` / `closePage` / `closeAllPages` | `isPageActionsSupported()` |
| `getPages()` list | — | ✅ | `typeof bridge.getPages === 'function'` + `.catch` |
| `onHistoricalDataUpdated` / `onMapDataUpdated` pushes | ✅ (picker changes) | ❌ not emitted | — refetch yourself |
| `onThemeUpdated` live theme switch | ✅ | ❌ not emitted — the page reloads with the new theme | register anyway |
| Native date/time/select controls | browser style | platform style & format | see `style.md` §7 |
| Gestures inside the widget | page scrolls normally | Android keeps the whole gesture in the widget | §4 |

Everything else — values, `sendValue`, selectors, device info, metadata, theme colors, `getHistoricalData` with named periods or `CUSTOM`, `getMapData` — works the same on every host.

The editor/browser preview (no bridge) renders like web but has no range picker, so history widgets show the in-widget picker there — that's a useful preview of the mobile look.

## 2. History & date ranges

**The rule:** if a history widget relies on the web range picker, it must also carry its own period picker for hosts without one. Web and mobile users get the same ability to change the time window.

| | Web (`isRangePickerSupported()` true) | Mobile / editor (false) |
|---|---|---|
| Who picks the window | The dashboard's date-range control, outside the widget | The widget: chips `6h · 24h · 7d · 30d` + optional `custom` from/to |
| Request | `period: 'RANGE_PICKER'` once | `period: 'CUSTOM', from, to` on every pick |
| Updates | `onHistoricalDataUpdated` pushes | Widget refetches; no pushes |
| X-axis domain | Data extent (the dashboard owns the window) | The **requested** `from…to`, so "24h" always looks like 24 hours |
| In-widget picker | **None** — never duplicate the dashboard control | Always shown above/below the chart |

- **Chips** mirror web's ranges with fewer options: `6h · 24h · 7d · 30d` (web offers 6h, 24h, 1w, 1mo). Lowercase labels. Default to the range the user asked for ("last day" → `24h`), else `24h`.
- **Custom range** (`custom` chip → From / To date fields) is on by default so mobile keeps the web picker's arbitrary ranges. Drop it (`allowCustom: false`) only in very compact tiles or when the user wants presets only. The picker validates `from ≤ to` and ≤ 365 days and clamps `to` to now.
- A fixed window ("always last 24 h", a sparkline in a value card) → no picker on any host; request that window directly.

Ready-made picker: `createPeriodPicker` + `createDateField` in §6, with its CSS.

### Wiring (put `onHistoricalDataUpdated` in the one skeleton `setCallbacks` call)

```js
const HISTORY_STREAMS = [{ index: 0, sourceType: 'AVG' }];
let requestSeq = 0;                                   // ignore responses from superseded picks

// in the skeleton: bridge.setCallbacks({ …, onHistoricalDataUpdated: data => drawChart(data, null) })

function loadHistory() {
  if (bridge.isRangePickerSupported()) {
    // Web: the dashboard picker owns the window. No in-widget picker.
    showLoading();
    bridge.getHistoricalData({ period: 'RANGE_PICKER', dataStreams: HISTORY_STREAMS })
      .then(data => drawChart(data, null))            // null window → axis from data extent
      .catch(() => showMessage('Could not load data'));
    return;
  }
  // Mobile / editor: the widget owns the window.
  createPeriodPicker(pickerSlot, {
    initial: '24h',
    onChange: ({ from, to }) => {
      const seq = ++requestSeq;
      showLoading();
      bridge.getHistoricalData({ period: 'CUSTOM', from, to, dataStreams: HISTORY_STREAMS })
        .then(data => { if (seq === requestSeq) drawChart(data, { from, to }); })
        .catch(() => { if (seq === requestSeq) showMessage('Could not load data'); });
    },
  });
}
```

Map widgets follow the same split: `getMapData({ index, period: 'RANGE_PICKER' })` + `onMapDataUpdated` on web; `getMapData({ index, period: 'CUSTOM', from, to })` from the in-widget picker elsewhere (map `CUSTOM` needs `from < to`).

Chart rules that depend on this split (ticks, tooltips) are in `components.md` → Chart.

## 3. Page navigation — mobile only

Mobile dashboards can contain custom-built pages; a widget can open one, go back, or return to the main dashboard. The web dashboard has no pages.

```js
const canNavigate = bridge.isPageActionsSupported();

function openPage(targetIndex) { if (canNavigate) bridge.showPage(targetIndex); }  // configured target, 0-based
function goBack()              { if (canNavigate) bridge.closePage(); }
function goHome()              { if (canNavigate) bridge.closeAllPages(); }
```

- `showPage(index)` takes the index of a **navigation target configured on this widget**, not a page id from `getPages()`. Label buttons with the names the user gave for each target, else "Page 1", "Page 2".
- Fire-and-forget: no completion callback. Give the button a pressed state on `pointerdown` only; don't show a spinner that never resolves.
- **On web** (`canNavigate` false):
  - Navigation is an extra on a widget that does something else (e.g. a gauge with a "details ›" link) → don't render the navigation control at all. No dead buttons.
  - Navigation is the widget's whole purpose (a page menu, back/home bar) → render the layout with the controls visibly disabled (`aria-disabled="true"`, `--text-muted`) and one muted caption: "Pages open in the Blynk mobile app".

## 4. Gestures, scrolling and touch

- Android keeps a gesture that **starts inside** the widget with the widget until touch-up. Internal scrolling and drags work without the dashboard stealing them; the dashboard scrolls from outside the widget.
- So content taller than the tile must scroll **inside** the widget: `html, body` stay `overflow: hidden`, and the scrolling region gets `flex: 1; min-height: 0; overflow-y: auto; overflow-x: hidden`. Native scrollbars are hidden on Android; scrolling still works.
- Never cancel intended scroll gestures: no blanket `preventDefault()` on `touchmove`/`wheel`, no `overscroll-behavior: none`.
- Controls that drag horizontally (sliders, chart scrubbing) use `touch-action: pan-y` on the drag surface so vertical swipes still scroll on web and iOS.

## 5. Text input and the iOS keyboard

Any widget with a text field hits this; it cost a full debugging round on the metadata widget.

- **16px inputs on touch** (`@media (hover: none)`). Below 16px iOS zooms the page on focus, which shifts everything sideways.
- **Don't autofocus on touch.** Focus the first field only where `matchMedia('(hover: hover)')` matches; on a phone it pops the keyboard and makes iOS scroll hard. Use `focus({ preventScroll: true })` on desktop.
- **iOS scrolls the DOCUMENT to reveal a focused input, ignoring `overflow: hidden`** — that's the "widget jumps away" report. You can't prevent it, so undo it: reset `window.scrollTo(0, 0)` and both `scrollTop`s, and bring the field back yourself.
- **Pin the focused FIELD, not its card.** In a tall form the card can sit correctly while the input being typed in is under the keyboard.
- **Bounds:** the ceiling is the widget header's bottom edge (pinning to viewport top hides the field behind the header); the floor is `visualViewport.height` minus a margin.
- **Correct repeatedly**, not once: iOS moves things across many frames and overshoots. Re-pin on a rAF loop for ~1s after focus, and again on `scroll`, on `visualViewport` `resize` (keyboard opens/closes) and on `input`.
- Give the scroller temporary `padding-bottom` while an editor is open on touch, or a field near the end of the list can't be lifted above the keyboard.

```js
function pinField() {
  resetDocumentScroll();
  const node = focusedField || editorNode;
  if (!node) return;
  const margin = 8;
  const ceiling = header.getBoundingClientRect().bottom + margin;
  const floor = (window.visualViewport ? visualViewport.height : innerHeight) - margin;
  const r = node.getBoundingClientRect();
  let delta = 0;
  if (r.bottom > floor) delta = Math.min(r.bottom - floor, r.top - ceiling);
  else if (r.top < ceiling) delta = r.top - ceiling;
  if (Math.abs(delta) > 1) scroller.scrollTop += delta;
}
```

## 6. History helper code

Copy what the widget needs into its `<script>` (inside the IIFE, after the skeleton's number/theme helpers). Sections 4–7 use the constants and formatters of section 3. Reuse this code rather than rewriting it.

```js
/* ── 3. Dates & times ───────────────────────────────────────────────────── */
// One fixed format everywhere, built by hand (never toLocale*/Intl defaults):
// "18 Sep 2026", "18 Sep 14:00", "14:00", "Sep 2026". Local clock, 24-hour.

const MINUTE_MS = 6e4, HOUR_MS = 36e5, DAY_MS = 864e5;
const MONTHS = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
const pad2 = n => String(n).padStart(2, '0');

function fmtTime(ms) { const d = new Date(ms); return pad2(d.getHours()) + ':' + pad2(d.getMinutes()); }
function fmtDay(ms) { const d = new Date(ms); return d.getDate() + ' ' + MONTHS[d.getMonth()]; }
function fmtDate(ms) { return fmtDay(ms) + ' ' + new Date(ms).getFullYear(); }
function fmtDayTime(ms) { return fmtDay(ms) + ' ' + fmtTime(ms); }
function fmtMonth(ms) { const d = new Date(ms); return MONTHS[d.getMonth()] + ' ' + d.getFullYear(); }

// Round DOWN to a step on the LOCAL clock (works for any step that divides a day).
// Plain Math.floor(ms/step)*step is UTC-aligned and lands on :30 in UTC+5:30.
function localFloor(ms, stepMs) {
  const offset = new Date(ms).getTimezoneOffset() * MINUTE_MS;
  return Math.floor((ms - offset) / stepMs) * stepMs + offset;
}
function localMidnight(ms) { const d = new Date(ms); d.setHours(0, 0, 0, 0); return d.getTime(); }


/* ── 4. History buckets ─────────────────────────────────────────────────── */

const GRANULARITY_MS = {
  MINUTE: MINUTE_MS, FIFTEEN_MINUTES: 15 * MINUTE_MS, HOURLY: HOUR_MS,
  DAILY: DAY_MS, WEEKLY: 7 * DAY_MS, MONTHLY: 30 * DAY_MS,
};

// granularity is null for RAW_DATA (and may be missing) → infer from median spacing.
function inferGranularity(points) {
  if (!points || points.length < 2) return 'MINUTE';
  const gaps = [];
  for (let i = 1; i < points.length; i++) gaps.push(points[i].x - points[i - 1].x);
  gaps.sort((a, b) => a - b);
  const median = gaps[Math.floor(gaps.length / 2)] || MINUTE_MS;
  let best = 'MINUTE', bestDistance = Infinity;
  for (const [name, ms] of Object.entries(GRANULARITY_MS)) {
    const distance = Math.abs(Math.log(median / ms));
    if (distance < bestDistance) { best = name; bestDistance = distance; }
  }
  return best;
}

// Start of the bucket containing ms, snapped to the local clock.
// Web's range picker starts at "now" rounded to 5 min, so raw x values read 08:05 — snap them.
function bucketStart(ms, granularity) {
  const d = new Date(ms);
  switch (granularity) {
    case 'MONTHLY': return new Date(d.getFullYear(), d.getMonth(), 1).getTime();
    case 'WEEKLY':  d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - (d.getDay() + 6) % 7); return d.getTime();
    case 'DAILY':   return localMidnight(ms);
    default:        return localFloor(ms, GRANULARITY_MS[granularity] || MINUTE_MS);
  }
}

// Tooltip precision follows the bucket, not the range: hourly bars show date + time
// even in a 7-day view; daily/weekly show the date; monthly shows "Sep 2026".
function bucketLabel(ms, granularity) {
  const start = bucketStart(ms, granularity);
  if (granularity === 'MONTHLY') return fmtMonth(start);
  if (granularity === 'DAILY' || granularity === 'WEEKLY') return fmtDate(start);
  return fmtDayTime(start);
}


/* ── 5. Time-axis ticks ─────────────────────────────────────────────────── */
// Ticks sit on round LOCAL times. Ladder keeps a 2-day step so a 7-day range
// gets labels (1d → 7 ticks, 1w → 1). Returns [{ t, label }], no repeats.
// maxTicks: ~6 for roomy charts, ~3–4 when the chart is ≤ 200px wide.

const TICK_STEPS = [MINUTE_MS, 5 * MINUTE_MS, 15 * MINUTE_MS, 30 * MINUTE_MS, HOUR_MS, 3 * HOUR_MS,
  6 * HOUR_MS, 12 * HOUR_MS, DAY_MS, 2 * DAY_MS, 7 * DAY_MS];
const MONTH_STEPS = [1, 2, 3, 6, 12];

function timeTicks(from, to, maxTicks = 6) {
  if (!(to > from)) return [];
  const span = to - from;
  let i = TICK_STEPS.findIndex(step => span / step <= maxTicks);
  if (i === -1) return monthTicks(from, to, maxTicks);

  let ticks = ticksForStep(from, to, TICK_STEPS[i]);
  if (ticks.length < 2 && i > 0) ticks = ticksForStep(from, to, TICK_STEPS[i - 1]);
  return dedupeLabels(ticks);
}

function ticksForStep(from, to, step) {
  const ticks = [];
  if (step < DAY_MS) {
    let t = localFloor(from, step);
    if (t < from) t += step;
    for (; t <= to; t += step) {
      const d = new Date(t);
      const midnight = d.getHours() === 0 && d.getMinutes() === 0;
      ticks.push({ t, label: midnight ? fmtDay(t) : fmtTime(t) });
    }
    return ticks;
  }
  const days = Math.round(step / DAY_MS);
  const d = new Date(localMidnight(from));
  if (d.getTime() < from) d.setDate(d.getDate() + 1);
  if (days === 7) while (d.getDay() !== 1) d.setDate(d.getDate() + 1);   // weeks start Monday
  for (; d.getTime() <= to; d.setDate(d.getDate() + days)) ticks.push({ t: d.getTime(), label: fmtDay(d.getTime()) });
  return ticks;
}

function monthTicks(from, to, maxTicks) {
  const start = new Date(from);
  const months = (new Date(to).getFullYear() - start.getFullYear()) * 12 + new Date(to).getMonth() - start.getMonth() + 1;
  const every = MONTH_STEPS.find(k => months / k <= maxTicks) || 12;
  const d = new Date(start.getFullYear(), start.getMonth(), 1);
  if (d.getTime() < from) d.setMonth(d.getMonth() + 1);
  const ticks = [];
  for (; d.getTime() <= to; d.setMonth(d.getMonth() + every)) {
    ticks.push({ t: d.getTime(), label: d.getMonth() === 0 ? String(d.getFullYear()) : MONTHS[d.getMonth()] });
  }
  return dedupeLabels(ticks);
}

function dedupeLabels(ticks) {
  return ticks.filter((tick, i) => i === 0 || tick.label !== ticks[i - 1].label);
}


/* ── 6. Scrubbing tooltip ───────────────────────────────────────────────── */
// One transparent hit area over the plot. Works for mouse and touch drags
// (per-bar pointerenter does not fire during a touch drag).
//   indexAt(fraction 0..1) → item index;  show(index);  hide()
// Touch: tooltip stays on the last item after lifting. Mouse: hides on leave.

function attachScrub(hitArea, { indexAt, show, hide }) {
  hitArea.style.touchAction = 'pan-y';                 // vertical swipes still scroll
  const pick = event => {
    const box = hitArea.getBoundingClientRect();
    if (box.width <= 0) return;
    const fraction = Math.max(0, Math.min(1, (event.clientX - box.left) / box.width));
    show(indexAt(fraction));
  };
  hitArea.addEventListener('pointerdown', event => {
    try { hitArea.setPointerCapture(event.pointerId); } catch (_) { /* element detached */ }
    pick(event);
  });
  hitArea.addEventListener('pointermove', event => {
    if (event.pointerType === 'mouse' || hitArea.hasPointerCapture(event.pointerId)) pick(event);
  });
  hitArea.addEventListener('pointerleave', event => { if (event.pointerType === 'mouse') hide(); });
}


/* ── 7. In-widget period picker ─────────────────────────────────────────── */
// For hosts WITHOUT the dashboard range picker (mobile apps, editor preview).
// Chips mirror web's ranges: 6h · 24h · 7d · 30d, plus an optional "custom"
// from/to range. onChange({ key, from, to }) fires on every selection; fetch
// with period:'CUSTOM'. Needs the CSS below.

const PERIODS = [
  { key: '6h', ms: 6 * HOUR_MS }, { key: '24h', ms: DAY_MS },
  { key: '7d', ms: 7 * DAY_MS }, { key: '30d', ms: 30 * DAY_MS },
];
const MAX_RANGE_MS = 365 * DAY_MS;

function createPeriodPicker(container, { initial = '24h', allowCustom = true, onChange }) {
  const make = (tag, className) => { const node = document.createElement(tag); if (className) node.className = className; return node; };
  const root = make('div', 'period-picker');
  const chips = make('div', 'period-picker__chips');
  chips.setAttribute('role', 'tablist');
  const customRow = make('div', 'period-picker__custom');
  const hint = make('span', 'period-picker__hint');
  customRow.hidden = true;

  let customFrom = null, customTo = null;

  function select(key) {
    for (const chip of chips.children) chip.setAttribute('aria-selected', String(chip.dataset.key === key));
    customRow.hidden = key !== 'custom';
    if (key === 'custom') { emitCustom(); return; }
    const to = Date.now();
    onChange({ key, from: to - PERIODS.find(p => p.key === key).ms, to });
  }

  function emitCustom() {
    hint.textContent = '';
    if (customFrom === null || customTo === null) { hint.textContent = 'Pick both dates'; return; }
    const from = customFrom;
    const to = Math.min(Date.now(), customTo + DAY_MS - 1);    // through the end of the "to" day
    if (from > to) { hint.textContent = 'Start is after end'; return; }
    if (to - from > MAX_RANGE_MS) { hint.textContent = 'Pick up to 365 days'; return; }
    onChange({ key: 'custom', from, to });
  }

  const keys = PERIODS.map(p => p.key).concat(allowCustom ? ['custom'] : []);
  for (const key of keys) {
    const chip = make('button', 'period-picker__chip');
    chip.type = 'button';
    chip.dataset.key = key;
    chip.setAttribute('role', 'tab');
    chip.textContent = key;
    chip.addEventListener('click', () => select(key));
    chips.appendChild(chip);
  }

  customRow.append(
    createDateField('From', ms => { customFrom = ms; emitCustom(); }),
    createDateField('To', ms => { customTo = ms; emitCustom(); }),
    hint,
  );
  root.append(chips, customRow);
  container.appendChild(root);
  select(initial);
  return { select };
}

// Native <input type="date"> shows the platform's own format (18.09.2026 /
// 18 Sep 2026 centred / 09/18/2026) and CSS can't change it. Keep the native
// input (so each platform keeps its picker) but hide its text and draw our own
// label on top. onPick(localMidnightMs | null).
function createDateField(placeholder, onPick) {
  const field = document.createElement('label');
  field.className = 'date-field';
  const input = document.createElement('input');
  input.type = 'date';
  input.setAttribute('aria-label', placeholder);
  const text = document.createElement('span');
  text.className = 'date-field__text is-placeholder';
  text.textContent = placeholder;

  input.addEventListener('click', () => { try { input.showPicker(); } catch (_) { /* already open / unsupported */ } });
  input.addEventListener('change', () => {
    const parts = input.value.split('-').map(Number);           // value is always YYYY-MM-DD
    const ms = parts.length === 3 && parts.every(Number.isFinite)
      ? new Date(parts[0], parts[1] - 1, parts[2]).getTime() : null;
    text.textContent = ms === null ? placeholder : fmtDate(ms);
    text.classList.toggle('is-placeholder', ms === null);
    onPick(ms);
  });
  field.append(input, text);
  return field;
}
```

The period picker and date field need this CSS:

```css
.period-picker { display: flex; flex-direction: column; gap: 8px; }
.period-picker__chips { display: flex; gap: 4px; flex-wrap: wrap; }
.period-picker__chip {
  -webkit-appearance: none; appearance: none; margin: 0; cursor: pointer;
  min-height: 28px; padding: 0 10px; border: 1px solid var(--field-border); background: transparent;
  font: 500 12px/1 var(--font-primary, system-ui, sans-serif); text-transform: lowercase;
  color: var(--text-secondary);
}
.period-picker__chip[aria-selected="true"] {       /* brand fill + onBrand text — never brand text */
  background: var(--brand); border-color: var(--brand); color: var(--on-brand);
}
.period-picker__chip:focus-visible { outline: 2px solid var(--text-primary); outline-offset: 1px; }
.period-picker__custom { display: grid; grid-template-columns: 1fr 1fr; gap: 4px; }
.period-picker__custom[hidden] { display: none; }
.period-picker__hint { grid-column: 1 / -1; font: 12px var(--font-primary, system-ui, sans-serif); color: var(--text-muted); }
.period-picker__hint:empty { display: none; }

.date-field { position: relative; display: block; min-height: 32px; border: 1px solid var(--field-border); }
.date-field input {                                 /* native input stays for the platform picker… */
  position: absolute; inset: 0; width: 100%; height: 100%; margin: 0; padding: 0; border: 0;
  background: transparent; font: inherit; -webkit-appearance: none; appearance: none;
  color: transparent; -webkit-text-fill-color: transparent;   /* …but its own text is hidden */
}
.date-field input::-webkit-datetime-edit { opacity: 0; }
.date-field input::-webkit-calendar-picker-indicator {        /* whole field opens the picker on desktop */
  position: absolute; inset: 0; width: auto; height: auto; margin: 0; opacity: 0; cursor: pointer;
}
.date-field__text {                                  /* our fixed-format, left-aligned label */
  position: absolute; left: 8px; right: 8px; top: 50%; transform: translateY(-50%);
  pointer-events: none; white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
  font: 13px var(--font-primary, system-ui, sans-serif); color: var(--text-primary);
}
.date-field__text.is-placeholder { color: var(--text-muted); }
```
