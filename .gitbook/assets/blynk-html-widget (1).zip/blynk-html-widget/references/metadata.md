# Device metadata — the contract

Read this **only when the widget actually shows or edits device metadata**. A widget that
only reads and writes datastreams never needs anything here; `bridge-api.md` §7 has the
three calls, which is all a datastream widget could want.

### Descriptor

```js
{ id, type, label, description, icon, mandatory, disabled, editable, displayValue, value, schema }
```

- **`value` is always an object**, even for a single value: `{ value: 'Air Conditioner2' }`, `{ time: 306 }`, `{ selectedOption: 'January' }`. Never treat it as a scalar.
- **`displayValue` is null in practice** — format from `value` rather than relying on it.
- The title is **`label`** (`name` may be absent).
- **Times are minutes since midnight**: `1020` → 17:00, `306` → 05:06.
- Unused sub-fields arrive as `null`, and placeholder strings occur (a Cost with `units: "None"`).
- Every device has the mandatory `DeviceName`, so **an empty list means no device is bound**, not "a device without metadata". Treat it as a preview context.
- A type from a newer server keeps its `type` string, is `editable: false` and has no `displayValue` — render from `value`, never throw.

### Which types accept a patch

Editable: `Text`, `Email`, `Tz`, `DeviceName`, `Number`, `Int`, `Measurement`, `List`, `Table`, `Unit`, `Contact`, `Location`.

Read-only in the widget: `Switch`, `Cost`, `Range`, `Time`, `Shift`, `Coordinates`, `Address`, `MultiText`, `Image`, `DeviceReference`, `DeviceOwner`, `HotspotName`, `Imei`, `ICCID`, `DeviceEui`, `JoinEui`, `BluesDevice`, `TheThingsNetwork`, `MyriotaTerminalId`, `ThingName`.

Never sent to the widget: `ApplicationKey`, `NetworkKey`, `OTASettings`.

Gate editing on this list *and* `d.editable`, and treat `disabled: true` as not editable. Don't write editors for read-only types — that's dead weight the host would reject anyway.

### Patch shapes

| Type | Patch |
|---|---|
| Text, Email, DeviceName, Tz, Number, Int, Measurement, Unit | `{ value: … }` |
| List | `{ selectedOption: 'March' }` |
| Contact | the enabled property names: `{ phone, email, … }` |
| Location | the property names: `{ siteName, lat, room, … }` |

`Contact` and `Location` list their editable parts in `schema.enabledFields` (camelCase: `buildingName`, `floorName`). Send only changed properties; omitted ones stay unchanged. Explicit `null` clears a property only where native validation permits it — send it for an emptied field and let a rejection surface inline.

```js
if (d.editable && d.schema.enabledFields.includes('room')) {
  bridge.updateDeviceMetadata({ id: d.id }, { room: '205' })
    .then(committed => { metadata.set(committed.id, committed); render(); })
    .catch(error => { /* error.code → inline state; the host already toasted */ });
}
```

Render the **committed** descriptor from the Promise, never the typed draft. Writes serialize per device/field, and a **timed-out write has an unknown outcome**: re-read with `{ refresh: true }`, compare the patched properties, then close the editor or offer a retry.

### Callback

Delivers committed descriptors once the host is ready, including changed `schema` or permissions (close an open editor if `editable` turns false). Identical snapshots are suppressed; registering the callback does not replace the initial read. A successful write may arrive through both its Promise and the callback — merge by `id`. Payloads are shallow copies; null/non-object payloads are dropped.


## Display and editing recipe

See `components.md` → "Device metadata card" for the card layout, per-type rendering,
editor controls, and the loading/demo behavior across preview contexts.
