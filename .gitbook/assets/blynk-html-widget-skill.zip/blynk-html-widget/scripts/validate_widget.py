#!/usr/bin/env python3
"""Validate a Blynk AnyWidget HTML file against the hard constraints.

Usage: python3 validate_widget.py path/to/widget.html
Exit code 0 = all checks pass, 1 = at least one failure (warnings don't fail).
"""
import re
import sys

LIMIT = 100000


def check(html: str):
    fails, warns = [], []
    n = len(html)

    if n > LIMIT:
        fails.append(f"size {n} chars exceeds the {LIMIT} hard cap (over by {n - LIMIT})")
    else:
        print(f"  size: {n}/{LIMIT} chars  ({LIMIT - n} to spare)")

    # Bridge fallback stub so it survives browser/editor preview.
    if "typeof BlynkBridge" not in html:
        fails.append("missing BlynkBridge fallback stub (no `typeof BlynkBridge` guard)")

    # Theme wiring.
    if "getTheme" not in html:
        fails.append("does not call getTheme() — widget won't follow the app theme")

    # Iframe reset.
    body_reset = re.search(r"html\s*,\s*body[^{]*\{[^}]*margin\s*:\s*0", html, re.I)
    if not body_reset:
        fails.append("missing html,body margin:0 reset")
    if "overflow:hidden" not in html.replace(" ", "") and "overflow: hidden" not in html:
        warns.append("no `overflow:hidden` on html/body — dashboard scroll may be hijacked")

    # Viewport.
    if not re.search(r'<meta[^>]+name=["\']viewport', html, re.I):
        fails.append("missing viewport meta tag")

    # No external resources.
    if re.search(r'<script[^>]+src\s*=', html, re.I):
        fails.append("external <script src> found — inline all JS (no CDN)")
    if re.search(r'<link[^>]+href\s*=\s*["\']https?:', html, re.I):
        fails.append("external <link href=\"http…\"> found — no CDN fonts/styles")
    if re.search(r'@import\s+url\(\s*["\']?https?:', html, re.I):
        fails.append("@import url(http…) found — no external CSS")

    # Promise safety: every getValue/getValues/getTheme/getHistoricalData/getDeviceInfo
    # call ought to have a nearby .catch — soft check.
    has_get = re.search(r'\bget(Values?|Theme|HistoricalData|DeviceInfo)\s*\(', html)
    handled = ".catch" in html or re.search(r'\.then\([^;]*,\s*function', html) or re.search(r'\.then\([^;]*=>', html)
    if has_get and not handled:
        warns.append("bridge get* call without any rejection handler — handle the no-bridge case")

    # innerHTML with possible bridge data.
    if "innerHTML" in html:
        warns.append("innerHTML used — prefer textContent/setAttribute for bridge values")

    return fails, warns


def main():
    if len(sys.argv) != 2:
        print("usage: validate_widget.py path/to/widget.html")
        sys.exit(2)
    with open(sys.argv[1], encoding="utf-8") as f:
        html = f.read()

    fails, warns = check(html)

    for w in warns:
        print(f"  WARN: {w}")
    if fails:
        print("\nFAIL:")
        for fl in fails:
            print(f"  - {fl}")
        sys.exit(1)
    print("\nPASS: all hard constraints satisfied.")
    sys.exit(0)


if __name__ == "__main__":
    main()
