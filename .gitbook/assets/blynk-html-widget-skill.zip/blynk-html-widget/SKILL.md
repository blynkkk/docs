---
name: blynk-html-widget
description: Generate a self-contained HTML widget for the Blynk dashboard wired to the BlynkBridge JavaScript API. Use this whenever the user wants a Blynk widget, an HTML Widget, a custom dashboard tile, or describes an IoT dashboard display/control need — a gauge, slider, switch, level/progress bar, value-or-label card, chart, or anything similar for one or more datastreams — whether they name the UI element ("I need a slider that sets the target temp") or only state the need ("show me the humidity over the last day"). Also trigger when editing, restyling, or debugging existing Blynk widget HTML, or wiring widget JavaScript to datastream values, the app theme, historical data, device info, or page navigation. Do not wait for the literal word "widget"; an IoT control/display need on Blynk is enough.
---

# Blynk HTML Widget Generator

Produce one self-contained `.html` file that drops straight into the Blynk dashboard's widget HTML field (`AnyMultiPinWidget.htmlCode`) with no further edits. The page runs inside a Blynk WebView that injects a `BlynkBridge` class before your scripts; through it the widget reads datastream values, writes them back, reacts to live pushes, reads the app theme, and fetches history.

The code must be clean, well-structured, and the most important - easy to read (human-readable).

The hard part is **interpretation**: the request sometimes names a UI element and sometimes only states a need. Pick the component that best serves the need — do not just transcribe a named element if a better one fits, and do not refuse a need because it isn't one of the catalogued families.

## Workflow

1. **Interpret the use case** → decide whether the widget *reads*, *writes*, or both, and choose a component (below).
2. **Map datastreams to sources** → one source per requested datastream; build for runtime discovery.
3. **Build from the mandatory skeleton** (below) → bridge stub, init flow, callbacks, theme.
4. **Style it** → user style/screenshot wins; else the matching reference sheet; else Blynk industrial baseline. See `references/style.md`.
5. **Validate** → run `scripts/validate_widget.py` on the file. Fix every failure (the 100k char cap is hard).
6. **Present** the `.html` file with `present_files`.

For exact API shapes (value objects, historical data, device info, theme fields, page nav, error handling) read `references/bridge-api.md`. For per-component build recipes and which reference image to study, read `references/components.md`.

## Step 1 — Interpret and choose a component

TThe families below are the *most common*, not a closed set. Compose them or invent a new layout when the need calls for it. Each maps to a reference image in `assets/refs/` — study the matching one for visual style.

| Need / phrasing | Component | R/W | Reference image |
|---|---|---|---|
| "set / adjust / change / control" a numeric value | Slider (vertical, horizontal, dial) | Write | `slider.webp` |
| "turn on/off", "toggle", "enable", or pick an ENUM mode | Switch / segmented selector | Write | `SWITCH.webp` |
| "history", "trend", "over time", "last N hours/days", graph | Chart (line, bar, sparkline, dot-matrix, radar) | Read | `CHARTS.webp` |
| "progress", "fill", "level", "% of capacity/goal" | Horizontal level / threshold bar | Read | `horizontal_level.webp` |
| a single current value that has a known min/max range | Radial / arc / semicircle gauge, ring | Read | `gauges.webp` |
| current value(s) with no time axis, or several metrics at once | Value / label card (single or grid) | Read | `LABEL_CARD_VALUE.webp` |

Selection rules of thumb:
- If the user must *change* the value → write component (slider or switch). Otherwise → read component.
- "Over time" / "history" is the strongest signal for a chart (uses `getHistoricalData`, not `getValues`). On web, prefer the host's built-in date-range picker — call `getHistoricalData({period:'RANGE_PICKER'})` guarded by `isRangePickerSupported()` — and fall back to `CUSTOM` or a fixed period elsewhere. Don't build a local date picker inside the widget unless explicitly asked for.
- A bounded measurement ("0–100 load", "sleep score") suits a gauge; an unbounded or label-like value suits a value card.
- When nothing fits cleanly, compose (e.g. value card + sparkline) or build a bespoke layout in the same style.

## Step 2 — Datastreams → sources

The widget can be assigned multiple datastreams; their count and types are discovered at runtime via `getValues()` (0-based index per stream). Build for whatever is assigned:

- **One requested datastream → one source.** Multiple → multiple, in assigned order.
- **Read components** (gauge, level, chart, value card) can aggregate several streams into one tile.
- **Write components** (slider, switch) can also drive multiple streams — render one control per assigned stream, each calling `sendValue(index, value)`.
- Never hardcode an index count. Derive it from `getValues().length`; show a "not configured" state when it is `0`, and a placeholder layout when the bridge is absent (editor preview).
- Stream type drives rendering: `INT`/`DOUBLE` carry `min`/`max`/`unit`/`suffix`/`decimalFormat`; `ENUM` carries `mappings[]` and `value` is the index string. See `references/bridge-api.md`.

## Step 3 — Mandatory skeleton

Every widget starts from this. The bridge stub keeps it working in the browser/editor; `setCallbacks` wires live updates; `init()` applies theme before rendering to avoid a color flash.

```<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, initial-scale=1.0, maximum-scale=1.0,
                 user-scalable=no, viewport-fit=cover">

  <title>My Widget</title>
  <style>/* your styles */</style>
</head>
<body>
  <!-- your markup -->

<script>
(function () {
  'use strict';

  // ① Create bridge
  const bridge = (typeof BlynkBridge !== 'undefined')
    ? new BlynkBridge({ logEnabled: true, isOnErrorEnabled: true })
    : {
        isBridgeAvailable: false,
        sendValue: () => {}, sendError: () => {}, log: () => {},
        setCallbacks: () => {}, setOnErrorEnabled: () => {}, setLogging: () => {},
        isExternalRequestsAllowed: () => false,
        getValue:               () => Promise.reject('no bridge'),
        getValues:              () => Promise.reject('no bridge'),
        getDeviceInfo:          () => Promise.reject('no bridge'),
        getTheme:               () => Promise.reject('no bridge'),
        isRangePickerSupported: () => false,
        getHistoricalData:      () => Promise.reject('no bridge'),
        isPageActionsSupported: () => false,
        showPage:               () => {},
        closePage:              () => {},
        closeAllPages:          () => {},
      };

  // ② Register callbacks
  bridge.setCallbacks({
    onValueUpdated: ({ index, value, type, label, pinType,
                       min, max, unit, suffix, decimalFormat,
                       mappings, enumFallbackValue }) => {
      // called whenever the server pushes a new value for one of the datastreams
      // — see "Reading Values" section for full field descriptions per type
    },
    onError: (message) => {
      // called when the platform reports an error (validation failures, timeouts, etc.)
      bridge.log('onError: ' + message);
    }
  });

  // ③ Apply theme tokens to your UI
  function applyTheme(theme) {
    // e.g. document.documentElement.style.setProperty('--bg-color', theme.backgroundColor);
  }

  // ④ Boot
  async function init() {
    const theme = await bridge.getTheme().catch(() => null);
    if (theme) applyTheme(theme);

    const values = await bridge.getValues().catch(() => []);
    // render your UI
  }

  init();
})();
</script>
</body>
</html>
```

In real widgets keep a `state` map keyed by `index` so `onValueUpdated` patches a single stream rather than re-rendering everything.

## Step 4 — Style

Priority: (a) explicit user style or pasted screenshot, (b) the reference sheet for the chosen component, (c) the Blynk industrial baseline. Always wire `getTheme()` so colors and fonts follow the live app theme, with the `:root` fallbacks above for the editor. Full palette, theming field map, and layout conventions are in `references/style.md`.

## Step 5 — Hard constraints

- **≤ 100000 characters** total. This is a hard cap — if you exceed it, simplify (drop decorative flourishes, shrink markup) rather than dropping required behavior. The validator enforces it.
- Note that 100k is a HARD CEILING ONLY. Never sacrifice quality or correctness
  to save characters — a 90,000-char widget is fine.
- **No external resources.** No `<script src>`, no CDN fonts/icons, no `@import url(http…)`. Hand-roll charts/gauges as inline SVG. Use system fonts.
- **Iframe reset** on `html,body`: `margin:0!important;padding:0!important;overflow:hidden` plus `touch-action:manipulation`, `-webkit-user-select:none` (already in the skeleton). Do **NOT** add `overscroll-behavior:none` — it stops the dashboard itself from scrolling, which is inconvenient.
- **WIdget has a no background color by default**. only paint an opaque background when the user explicitly asks for one. (The value/label card's mobile tint is the single exception — see `references/components.md`.)
- **Cross-platform safe.** Guard `isExternalRequestsAllowed()` before `fetch()`, `isPageActionsSupported()` before page nav, `isRangePickerSupported()` before RANGE_PICKER; fall back otherwise.
- **Always `Promise`-based** bridge calls → chain `.catch()` on every one.
- **No `innerHTML` with bridge data** → use `textContent` / `setAttribute` / DOM APIs.

## Step 6 — Validate and present

```bash
python3 scripts/validate_widget.py path/to/widget.html
```

It checks char count, the bridge fallback stub, `getTheme` wiring, the iframe reset, the viewport meta, and the absence of external resources, and warns on `innerHTML`. Fix all failures, then `present_files` the `.html`.

## Reference files

- `references/bridge-api.md` — complete BlynkBridge API: value-object shapes, sending, errors, real-time callbacks, device info, theme fields, historical data, page navigation, support checks. Load when you need exact field names or method signatures.
- `references/components.md` — per-family build recipe (which datastream fields, read/write wiring, layout notes) and which `assets/refs/*.webp` to study.
- `references/style.md` — Blynk palette, `getTheme()` → CSS-variable map, industrial-style conventions, responsive/container-query layout.
- `assets/refs/*.webp` — — the component style sheets;; view the one matching the chosen family before writing CSS.
