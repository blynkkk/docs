# BlynkBridge API Reference

The Blynk WebView injects `BlynkBridge` before your scripts. Every method returns a `Promise` (even though backed by sync native calls) except the fire-and-forget ones (`sendValue`, `sendError`, `log`, page nav). Always `.catch()`. In the browser/editor `BlynkBridge` is undefined — use the fallback stub from SKILL.md.

The code must be clean, well-structured, and the most important - easy to read (human-readable).

## Contents
1. Construction & availability
2. Reading values (value-object shapes)
3. Sending values
4. Real-time callbacks
5. Errors
6. Theme
7. Device info
8. Historical data
9. Page navigation
10. Support / permission checks

---

## 1. Construction & availability

```js
const bridge = new BlynkBridge({ logEnabled: true, isOnErrorEnabled: true });
bridge.isBridgeAvailable();          // true inside the WebView, false in browser/editor
```
Constructing also defines `window.blynkWidgetUpdate(json)` and `window.blynkOnError(msg)`, which the platform calls directly — do not delete them.

## 2. Reading values

```js
bridge.getValue(index)   // → Promise<ValueObject>   (0-based; rejects index_out_of_bounds)
bridge.getValues()       // → Promise<ValueObject[]> ([] when no datastreams assigned)
```

**Common fields** on every ValueObject: `index` (number, 0-based), `value` (**always a string**), `type` (`"INT"|"DOUBLE"|"STRING"|"ENUM"|…`), `label` (string|null), `pinType` (string|null, e.g. `"VIRTUAL"`).

**Numeric (`INT`/`DOUBLE`)** add: `min`, `max` (number), `unit` (string, may be ""), `suffix` (string, **present only when non-empty**), `decimalFormat` (string|null, e.g. `"#.##"`, double only).
```js
{ index:0, value:"23", type:"INT", label:"Temperature", pinType:"VIRTUAL",
  min:-40, max:85, unit:"Celsius", suffix:"°C" }
```
Render: `parseFloat(v.value)`, format with `decimalFormat` if present, append `suffix` if present.

**Enum (`ENUM`)** add: `mappings` (string[] of option labels), `enumFallbackValue` (string, optional). `value` is the **numeric index as a string** into `mappings`.
```js
const idx = parseInt(v.value,10);
const label = v.mappings?.[idx] ?? v.enumFallbackValue ?? v.value;
```

## 3. Sending values

```js
bridge.sendValue(index, value);   // index 0-based; value string|number; fire-and-forget
```
For ENUM writes send the index string (`"0"`,`"1"`,…). For switches send the value your datastream expects (e.g. `"1"`/`"0"` or an ENUM index).

## 4. Real-time callbacks

Register once, after constructing the bridge, before any history subscription:
```js
bridge.setCallbacks({
  onValueUpdated: (v) => { /* same shape as a ValueObject; merge by v.index */ },
  onError:        (msg) => { /* platform validation/timeout errors */ },
  onThemeUpdated: applyTheme,
  onHistoricalDataUpdated: ({ streams }) => { /* RANGE_PICKER pushes only */ }
});
```
The platform calls `window.blynkWidgetUpdate(json)` on server pushes → dispatched to `onValueUpdated`.

## 5. Errors

```js
bridge.sendError("message");        // shows an error toast in the dashboard
bridge.setOnErrorEnabled(false);    // mutes both sendError() and the onError callback
```
No-op when `isOnErrorEnabled` is false, message empty, or bridge absent. The `onError` callback fires on timeouts and server errors when enabled (the default).

## 6. Theme

```js
bridge.getTheme();   // → Promise<Theme|null>  (null outside the WebView)
```
Colors are `#rrggbbaa` hex, already resolved for the current light/dark mode — no `prefers-color-scheme` logic needed inside the app (keep it only as an editor fallback).

Color fields: `brand` (primary accent), `primary` (secondary accent), `positive` (success/online), `warning`, `critical` (error/offline), `background`, `textPrimary`, `onPrimary` (text on primary surfaces), `onBrand` (text on brand surfaces), `neutral` (muted text/borders).

Font fields (`string|null`, override CSS `font-family` only when non-null): `primaryFont`, `secondaryFont`, `buttonsFont`, `widgetValuesFont`.

Apply all as CSS custom properties so the page updates atomically (see SKILL.md `applyTheme`). A 15%-opacity accent ghost: `theme.brand + '26'`.

## 7. Device info

```js
bridge.getDeviceInfo();   // → Promise<DeviceInfo|null>   (null = no device linked → guard it)
```
```ts
{ id:number, orgId:number, name:string,
  lastReportedAt:number,  // Unix ms, 0 if never reported
  status?:string }        // 'ONLINE' | 'OFFLINE' | custom; absent when unset
```
**Note:** "device status" and "lifecycle status" are the same thing. Read it from `info.status`; treat any custom string case-insensitively (`.toUpperCase()`). Online → `positive` color, offline → `critical`, custom → `neutral`.

## 8. Historical data

```js
bridge.getHistoricalData(options);   // → Promise<{ streams: [...] }>
```
`options`:
- `period` (required): `'ONE_HOUR'|'SIX_HOURS'|'DAY'|'WEEK'|'MONTH'|'THREE_MONTHS'|'SIX_MONTHS'|'ONE_YEAR'|'CUSTOM'|'RANGE_PICKER'`.
- `from`,`to` (CUSTOM only): Unix **ms**; `from ≤ to`; `to-from ≤ 365 days`.
- `offset` (optional): non-negative int; skip N points, RAW_DATA pagination only.
- `dataStreams` (required, non-empty): `[{ index, sourceType }]`.
  - `index`: **0-based** (consistent with getValue/sendValue). The README is contradictory here — a couple of lines imply 1-based via a `< 1` server error. If your backend rejects with `index_out_of_bounds` on a valid stream, retry with `index+1`. Default to 0-based.
  - `sourceType`: `'RAW_DATA'|'MIN'|'MAX'|'AVG'|'SUM'|'COUNT'`.

Returns:
```ts
{ streams: [ { index:number,
               granularity:'MINUTE'|'FIFTEEN_MINUTES'|'HOURLY'|'DAILY'|'WEEKLY'|'MONTHLY'|null,
               values:[ { x:number /*ms*/, y:number } ] } ] }
```
`granularity` is **null** for `RAW_DATA` (no bucketing) — null-check before using it. Native side has a **60 s timeout**; plan a loading/timeout state.

**RANGE_PICKER** (web only; check `isRangePickerSupported()`): subscription model. Register `onHistoricalDataUpdated` *before* calling `getHistoricalData({period:'RANGE_PICKER'})`; the first call resolves with current data and registers the subscription, then every picker change pushes fresh data to the callback (not a Promise). On Android/iOS use `CUSTOM` with explicit `from`/`to` instead.

```js
bridge.getHistoricalData({ period:'DAY',
  dataStreams:[{index:0,sourceType:'AVG'},{index:1,sourceType:'MIN'}] })
  .then(({streams}) => renderChart(streams))
  .catch(e => bridge.log('history: '+e));
```

## 9. Page navigation (fire-and-forget; no return)

```js
bridge.showPage(index);   // 0-based page widget
bridge.closePage();       // back one level
bridge.closeAllPages();   // back to main dashboard
```
Guard with `isPageActionsSupported()` (true on Android/iOS, false on web).

## 10. Support / permission checks

```js
bridge.isExternalRequestsAllowed();  // true Android/iOS, false web — check before fetch()
bridge.isPageActionsSupported();     // true Android/iOS, false web
bridge.isRangePickerSupported();     // true web only
```
Even when `isExternalRequestsAllowed()` is true, CORS may still block a request — handle `fetch()` rejections.
