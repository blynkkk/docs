# Component Recipes

The families below are the common cases, not a closed set — compose or invent when a need doesn't fit. For each, study the matching `assets/refs/*.webp` before writing CSS, then build on the SKILL.md skeleton. All read from `getValues()` / `onValueUpdated`; write families also call `sendValue`.

---

## Gauge — `gauges.webp` (read)
A single bounded numeric value as a radial/arc/semicircle dial or ring; big centered value + label below.
- Fields: `min`, `max`, `value`, `suffix`, `decimalFormat`, `label`.
- Geometry: inline SVG. Sweep = `(value-min)/(max-min)` clamped to [0,1]. Use `stroke-dasharray`/`stroke-dashoffset` on an arc path or two stacked circles (track + progress).
- Variants seen: full ring with % center, ~270° open gauge, segmented tick gauge ("sleep score" dashes), thin arc with avg marker.
- Multiple streams → small multiples (one mini-gauge per stream) or a labelled grid.

## Slider — `slider.webp` (write)
Set/adjust a numeric datastream by dragging.
- Fields: `min`, `max`, `value`, `suffix`. Read initial value, render thumb, on release `sendValue(index, newValue)`.
- Variants: vertical track with tick scale + glowing fill, horizontal split fill, thermostat dial column, dual-handle range row.
- Use pointer events; debounce; show the live value large. Send on `pointerup`/`change`, not every move, to avoid flooding.
- Multiple streams → stack one labelled slider per assigned stream.

## Switch / button / selector — `buttons_switches.webp` (write)
Anything the user taps to set a value, pick a mode, fire an action, or step a number. This reference sheet covers the whole tap-to-write family — not just toggles.
- **Binary toggle:** pill toggle, knurled handle, day/night, labelled row with sublabel (e.g. "Power On / Living Room"). `sendValue(index, on?"1":"0")` (or the value your stream expects). Reflect confirmed state from `onValueUpdated` rather than assuming the tap succeeded.
- **ENUM / segmented selector:** segmented control built from `mappings[]`; current = `parseInt(value)`; send the chosen index string. Icon-per-option mode grids (Hot / Cold / Dry Air / Humid; Auto / Cool / Heat) are the same pattern — one active option, send its index.
- **Momentary action button:** a press that triggers something rather than holding a state — "Remote Control", record/effects/settings-style icon buttons, an "Additions" primary button. Send a fixed value on `pointerup` (e.g. `sendValue(index, "1")`, or a pulse the datastream expects); do **not** keep it visually latched unless the stream reports back an on state.
- **Preset buttons:** a row of fixed choices that each write one value — e.g. "Schedule Turn Off → Off / 13:00 / 14:00 / 15:00". Render as a button group; highlight the one matching the current value; send the chosen preset's value.
- **Stepper (± button pair):** increment/decrement a number by a fixed step ("LEVEL 4" with +/−). Clamp to `min`/`max`, send the new value on each tap, debounce rapid presses.
- Multiple streams → one control per stream, labelled.

## Value / label card — `LABEL_CARD_VALUE.webp` (read)
Current value(s) with no time axis; the default when no range or trend is implied.
- One stream → big monospace value + unit + small label/sublabel + optional device badge.
- Several streams → a card grid (2×2 etc.), each cell label + value, colored accents.
- Good for STRING streams and unbounded numbers. Pair with a tiny sparkline only if the user implies recent movement.
- **Mobile only:** give the card a subtle tinted surface by default — a light grey fill with ~`0.5rem` border-radius (e.g. `background:rgba(127,127,127,.10);border-radius:.5rem`, or `var(--surface)` if it reads as a tint). Gate it on a mobile check — `bridge.isPageActionsSupported()` is `true` on Android/iOS, `false` on web — and keep the background transparent on web. This is the one value-card exception to both the transparent-background default and the industrial "no rounded corners" baseline, so don't let those rules strip it.

## Chart — `CHARTS.webp` (read, uses history)
Any "over time / history / trend" need. Uses `getHistoricalData`, not `getValues`.
- Pick `period` from the phrasing ("last hour"→`ONE_HOUR`, "today"→`DAY`, "this week"→`WEEK`…); `sourceType` `AVG` by default, `RAW_DATA` for dense raw points.
- Render inline SVG: line/area, bar, sparkline, dot-matrix grid, or radar. Map `values[].x` (ms) to X, `y` to Y; auto-scale Y to data min/max.
- Show loading + 60 s-timeout + empty states.
- Multiple streams → overlaid series with a small legend, or stacked mini-charts.
- For "over time" / "history" widgets, support the Date Range Control on web
  (isRangePickerSupported: () => true). Do not add a local date picker inside the
  widget unless explicitly asked.
- Time axis labels: pick clean intervals from a standard ladder (15m, 30m, 1h,
  6h, 1d) rather than dividing the span into N equal chunks; snap to boundaries
  with Math.ceil(minX/step)*step; never repeat the same label consecutively; use
  24-hour zero-padded time format; simplify the date to the bare minimum when
  widget width is below ~200px.

## Schedule / timer / date-time picker — `date_picker_timer.webp` (write, some read)
Setting or showing a *time*: a countdown, a duration, a calendar date/time, a recurring weekly schedule, or a clock readout. These write a time/schedule value to the datastream (or read one back to display); the stream is usually `STRING` (a time/JSON payload), `INT` (seconds/minutes, or an epoch), or `ENUM`-like presets.
- **Countdown / timer:** big `MM:SS` (or `HH:MM`) readout + progress bar + start/pause/reset controls (see the `31:47 / 60 min` card). If the widget owns the countdown, drive it locally with `requestAnimationFrame`/`setInterval` and write remaining seconds (or a running flag) back on start/pause/reset. If the device owns it, read remaining time from the stream and just render.
- **Duration setter:** a scrollable wheel or preset chips (`5m / 10m / 25m`, `60:00`) to pick how long. Send the chosen duration in the unit the stream expects (seconds vs minutes — check `unit`/`suffix`).
- **Calendar date picker:** month grid with prev/next, one selected day, optional time-slot list beside it ("booked for Thursday, June 12 at 10:00"). Send the selected date/datetime as the stream's expected format (epoch ms, ISO string, or `YYYY-MM-DD`).
- **Weekly schedule:** per-day rows with a toggle and one or more time ranges (`Mon … Tue 7:00 AM–8:00 AM + Add More`). Serialize to whatever the stream stores (usually a JSON string); send on edit. This is a compound control — keep local edit state and write the whole schedule object at once, not per keystroke.
- **Clock / world clock readout (read):** current time, multi-zone list, or a sleep-phase strip. Pure display — format from the value or the device clock; no write.
- **24-hour clock** for any time-of-day rendering (`14:00`, zero-padded), consistent with the chart time-axis rule.
- Multiple streams → one scheduler/timer block per stream, labelled, or a shared calendar writing to several.

Date-range wiring (web RANGE_PICKER, mobile CUSTOM). Put `onHistoricalDataUpdated` in the *single* `setCallbacks({...})` call from the skeleton — register it before the history call, not in a second `setCallbacks`:
```js
const ds=[{index:0,sourceType:'AVG'}];
function draw({streams}){/* render SVG from streams[].values[].{x:ms,y} */}
// skeleton callbacks: setCallbacks({onValueUpdated, onError, onHistoricalDataUpdated:draw})
if(bridge.isRangePickerSupported()){            // web → host date-range picker drives it
  bridge.getHistoricalData({period:'RANGE_PICKER',dataStreams:ds})
    .then(draw)                                 // initial data; later picker changes push to onHistoricalDataUpdated
    .catch(e=>bridge.log('history: '+e));
}else{                                           // mobile/editor → fixed window, no picker
  const to=Date.now(),from=to-864e5;            // last 24h; pick from phrasing
  bridge.getHistoricalData({period:'CUSTOM',from,to,dataStreams:ds})
    .then(draw).catch(e=>bridge.log('history: '+e));
}
```
On mobile, RANGE_PICKER is unavailable — use `CUSTOM` (`from`/`to` in ms, `to-from ≤ 365d`) or a named period like `DAY`/`WEEK`. The `RANGE_PICKER` resolve + push split is detailed in `bridge-api.md` §8.

### Time axis labels
The X axis spans `[minX, maxX]` taken from the data (or the picked range). Label it with **clean clock intervals**, not raw point spacing — a reader parses "every hour" instantly and "every 17 minutes" not at all. Four rules, easiest to keep in one small label helper:

- **Snap to a nice step.** Measure the visible span, then pick a step from a fixed ladder so ~3–6 ticks fit: `1m, 5m, 15m, 30m, 1h, 3h, 6h, 12h, 1d, 1w, 1mo`. Place ticks on round clock boundaries (top of the hour, the :15/:30/:45 mark, midnight, the 1st) — start from `Math.ceil(minX/step)*step` and walk by `step`, never by dividing the span into N equal arbitrary chunks. That division is exactly what produces 17-minute gaps. Roughly match the step to `granularity` (MINUTE→minutes, HOURLY→hours, DAILY→days) so ticks don't fall between buckets.
- **No repeated labels.** After formatting, every adjacent label must differ. If the step is finer than the format's resolution (e.g. 20-min ticks all rendering as `15:00`), either coarsen the step or widen the format until they're distinct — `3 PM, 3 PM, 3 PM` is a bug, not a dense axis. Dedupe as a final guard: drop a tick whose formatted text equals its neighbour's.
- **24-hour clock for time-of-day.** Render `14:00`, never `2 PM` or `2:00 PM`; zero-pad to two digits (`09:00`).
- **Shrink the format with the tile.** Read the chart's rendered width (`@container` query or `clientWidth`). At/below ~200px, drop to the bare minimum — time only (`14:00`) for intraday ranges, date only (`Jun 3` or `06/03`) for multi-day — never both, and thin to 2–3 ticks. Above that a compact combined label is fine (`Jun 3 14:00`). Always match resolution to span: sub-day → time, multi-day → date, multi-month → month (`Mar`) or month/year.

---

## Read vs write quick test
User must *change* the value → slider or switch (write). Otherwise read. "Over time" → chart. Bounded single value → gauge. Progress/fill → level bar. Plain current value(s) → value card.
