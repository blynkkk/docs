# Style & Theming

Priority order, always:
1. **Explicit user style or a pasted screenshot** — match it.
2. **The reference sheet** for the chosen component (`assets/refs/*.webp`).
3. **Blynk industrial baseline** (below) when nothing else is specified.

These are *defaults*. Never weaken or override a style the user asked for to satisfy the baseline.

## Live theming with getTheme()

Always wire `getTheme()` so the widget follows the app's current light/dark theme; keep `:root` fallbacks for the editor/browser. Apply every value as a CSS custom property so the page repaints atomically.

`getTheme()` → CSS variable map:

| Theme field | CSS var (suggested) | Use |
|---|---|---|
| `brand` | `--brand` | primary accent, fills, focus, do not use for text, use only for accents |
| `primary` | `--primary` | secondary accent, do not use for text, only for accents |
| `positive` | `--positive` | positive change / success / online |
| `warning` | `--warning` | warnings |
| `critical` | `--critical` | negative change / errors / offline |
| `background` | `--bg` | widget background |
| `textTitle` | `--text-title` | Title, Main value text |
| `textEmphasis` | `--text-body` | body text |
| `textSecondary` | `--text-secondary` | description, small text |
| `neutral` | `--muted` | muted text / borders |
| `onBrand` / `onPrimary` | `--on-accent` | text on accent surfaces |
| `primaryFont` | `--font-primary` | body/labels (only if non-null) |
| `widgetValuesFont` | `--font-values` | numeric values (only if non-null) |
| `secondaryFont` / `buttonsFont` | `--font-secondary` / `--font-buttons` | captions / buttons |

Colors are `#rrggbbaa`; append `'26'` for ~15% opacity ghosts. Light/dark is already resolved by the host — the `@media (prefers-color-scheme)` block in the skeleton is only for the editor preview.

## Blynk industrial baseline

Aesthetic: sharp rectangular geometry, **no rounded corners, no soft shadows, no glow effects**, high contrast, dense purposeful layout, solid borders/fills, **uppercase labels with wide letter-spacing**, **monospace bold values**.

**Never add a glow effect** (e.g. `box-shadow` / `text-shadow` / `filter: drop-shadow()` used as a halo, neon bloom, or aura) unless the user explicitly asked for one in their prompt. This is a hard rule, not a baseline default — it holds even when matching a reference sheet or a pasted screenshot. Only add a glow if the user explicitly requests it.

Palette:
- Black `#000` / `#03030A`, white `#fff` - the main color. All shades of black. Colors is just for accents or the main elements that need t pay attention (as horizontal level for example)
- Brand / Neon green-yellow `#D1FF39` / `#C8FF1A`
- Primary / Neon green `#10F17F` / `#10F17F`
- Blue accent `#0000FE`, cyan `#3AF1F5`, deep blue `#3100FF`, secondary blue `#0000FF`
- Hot pink accent `#FC00B1`, light pink `#FF70FE`, violet `#8300E8`
- Warning yellow `#FFC104`, orange `#FF9C14`, brick `#BD4B04`, salmon `#FF9A61`
- Critical red `#FE1205`, dark red `#9B1005`
- Positive green `#3FA038`

## Layout
- Use 4-Point grid
- The tile is any size → `container-type:size` on `.stage` and `@container` queries for compact vs roomy.
- Fluid type: `clamp(12px, 5cqmin, 28px)`; container units `cqw/cqh/cqmin/cqmax` are supported.
- Reset (in skeleton): `html,body{margin:0!important;padding:0!important;overflow:hidden}` + `touch-action:manipulation` + `-webkit-user-select:none`.
- No CDN fonts/icons — system font stack and inline SVG only. Keep total ≤ 100000 chars.
- Background is transparent by default, unless it's explicitly defined in prompt. Exception: the value/label card gets a subtle tinted surface (light grey, ~`0.5rem` radius) on mobile only — see `components.md`.
- No padding around the content. The AnyWidget container already applies its own
  padding — do not add outer padding on .stage or a top-level wrapper or it
  doubles up. Spacing between inner elements is fine.
- Do NOT add `overscroll-behavior:none` — it prevents the dashboard from scrolling.

## Fonts
- Always set font-family: var(--font-primary), system-ui, sans-serif (keep system-ui as the
  fallback after the variable).
- Text contrast: 4.5:1 for body text, 3:1 for large text.



